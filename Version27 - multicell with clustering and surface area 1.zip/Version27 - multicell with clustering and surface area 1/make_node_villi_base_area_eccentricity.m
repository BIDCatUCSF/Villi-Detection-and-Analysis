function[node_perimeter,node_ecc,node_base_area]=make_node_villi_base_area_eccentricity(cell_flat1,cell_villus,node_number)

%defining node
node_perimeter=node_number;
node_perimeter(:,4)=0;
node_ecc=node_number;
node_ecc(:,4)=0;
node_base_area=node_number;
node_base_area(:,4)=0;


%get element
for d=1:size(cell_flat1,1)
    
    %get element from cell array
    cell_flat1_data_tmp=cell_flat1(d,1);
    cell_flat1_data=cell_flat1_data_tmp{1};
    
    %get the villus number
    v_num_tmp=cell_villus(d,3);
    v_num=v_num_tmp{1};

    %figure image
    cell_flat1_data_scaled=cell_flat1_data;
    xmin_flat=min(cell_flat1_data(:,1));
    ymin_flat=min(cell_flat1_data(:,2));
    cell_flat1_data_scaled(:,1)=(cell_flat1_data_scaled(:,1)-xmin_flat+1);
    cell_flat1_data_scaled(:,2)=(cell_flat1_data_scaled(:,2)-ymin_flat+1);
    flat_im=zeros(uint16(max(cell_flat1_data_scaled(:,1))),uint16(max(cell_flat1_data_scaled(:,2))));
    
    for a=1:numel(cell_flat1_data_scaled(:,1))
        if cell_flat1_data_scaled(a,4)~=-1000
            flat_im(uint16(cell_flat1_data_scaled(a,1)),uint16(cell_flat1_data_scaled(a,2)))=1;
        end
    end
    
    %figure, imagesc(flat_im); colormap(gray); colorbar; hold on; title(num2str(d));
    
    %calculating the convex hull
    stats=regionprops(flat_im,'ConvexHull');
    cv_test=stats.ConvexHull;
    %plot(cv_test(:,1),cv_test(:,2),'r','LineWidth',1.5);
    im_cv=poly2mask(cv_test(:,1),cv_test(:,2),size(flat_im,1),size(flat_im,2));
    figure, imagesc(im_cv); colormap(gray); colorbar; hold on; 
    
    %calculate perimeter
    stats_p=regionprops(im_cv,'Perimeter');
    perimeter_now=stats_p.Perimeter;
    
    %calculate eccentricity
    stats_e=regionprops(im_cv,'Eccentricity');
    ecc_now=stats_e.Eccentricity;
    
    %calculate relative base area
    idx_for_ba=find(im_cv>0);
    if numel(idx_for_ba)>0
        the_base_area=numel(idx_for_ba);
    else
        the_base_area=0;
    end
    
    the_title=strcat('Perimeter=',num2str(perimeter_now),' -- ','Eccentricity=',num2str(ecc_now));
    title(the_title);
    
    %add to node matrix
    idx_where=find(node_number(:,4)==v_num);
    if numel(idx_where)>0
        node_perimeter(idx_where,4)=perimeter_now;
        node_ecc(idx_where,4)=ecc_now;
        node_base_area(idx_where,4)=the_base_area;
    end
    
    %clear statements
    clear cell_flat1_data_tmp; clear cell_flat1_data;
    clear cell_flat1_data_scaled; clear xmin_flat; clear ymin_flat;
    clear flat_im;
    clear stats; clear cv_tes; clear im_cv;
    clear stats_p; clear perimeter_now; clear stats_e; clear ecc_now;
    clear v_num; clear v_num_tmp; clear idx_where;
    clear the_base_area; clear idx_for_ba;
    
end







