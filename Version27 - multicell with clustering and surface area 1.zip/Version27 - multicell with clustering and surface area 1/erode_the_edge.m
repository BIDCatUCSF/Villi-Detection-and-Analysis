function[final_im_to_save]=erode_the_edge(the_bound,im_now)

%making the image double (floating point);
im_now=double(im_now);

%structuring element for erosion
nhood=[0 1 0; 1 1 1; 0 1 0];

%binary mask
bw_im=poly2mask(the_bound(:,1),the_bound(:,2),size(im_now,1),size(im_now,2));
bw_im=double(bw_im);

% figure, imagesc(bw_im); colormap(jet); colorbar; title('Binary Matrix');

%the erosion
J = imerode(bw_im,nhood);
J2 = imerode(J,nhood);
J3 = imerode(J2,nhood);
erode_mask=[J+bw_im+J2+J3];

%figure, imagesc(erode_mask); colormap(jet); colorbar; title('Erode mask');

%making a new mask
new_mask=zeros(size(im_now));
new_mask=double(new_mask);
idx_mask1=find(erode_mask==1);
idx_mask2=find(erode_mask==2);
idx_mask3=find(erode_mask==3);
new_mask(idx_mask1)=1;
new_mask(idx_mask2)=1;
new_mask(idx_mask3)=1;

%new masked image
final_im_to_save=new_mask.*im_now;

    
    
   