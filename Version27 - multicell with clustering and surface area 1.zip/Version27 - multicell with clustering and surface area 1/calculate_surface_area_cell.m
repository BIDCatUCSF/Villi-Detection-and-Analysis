function[tot_surface_area]=calculate_surface_area_cell(node_of_curvature_to_save,the_face,zscale_fac)

% inputs
% node_of_curvature_to_save(:,1) = y coordinates of mesh
% node_of_curvature_to_save(:,2) = x coordinates of mesh
% node_of_curvature_to_save(:,3) = z coordinates of mesh
% the_face = mapping of how to assemble nodes.
% zscale_fac = 1 or 1.75, it is the scaling for LLS system

%output
%tot_surface_area = the surface area in square microns;

%making sure it is double
node_of_curvature_to_save=double(node_of_curvature_to_save);

%eliminating the top and bottom
min_z2=min(node_of_curvature_to_save(:,3))+2;
max_z2=max(node_of_curvature_to_save(:,3))-2;


%making things a little simple
x_go=node_of_curvature_to_save(:,1);
y_go=node_of_curvature_to_save(:,2);
z_go=node_of_curvature_to_save(:,3);



%some scaling before unit conversion
%zscale_fac = 1.75 for LLS
%zscale_fac = 1.00 for everything else
%z_go=z_go./zscale_fac;

%unit conversion
%This is strictly assuming that we are using LLS system here at UCSF
%Later I will generalize this
x_go=x_go.*0.1;
y_go=y_go.*0.1;
z_go=z_go.*0.1;

% x_go=x_go.*1;
% y_go=y_go.*1;
% z_go=z_go.*1;

%counter
count_c=1;

%figuring out the surface area (in units of micron squared)
for c=1:numel(the_face(:,1))

    %get the vertices of the triangle
    x1=x_go(the_face(c,1));
    y1=y_go(the_face(c,1));
    z1=z_go(the_face(c,1));
    
    x2=x_go(the_face(c,2));
    y2=y_go(the_face(c,2));
    z2=z_go(the_face(c,2));
    
    x3=x_go(the_face(c,3));
    y3=y_go(the_face(c,3));
    z3=z_go(the_face(c,3));
    
    if z1>min_z2 && z2>min_z2 && z3>min_z2 && z1<max_z2 && z2<max_z2 && z3<max_z2
    
        %making vectors with mutual origin
        A=[x1-x2;y1-y2;z1-z2];
        B=[x3-x2;y3-y2;z3-z2];
        
        %cross product
        C = cross(A,B);
        
        %magnitude of cross product
        mag_c=(((C(1).^2)+(C(2).^2)+(C(3).^2)).^0.5);
        
        if count_c==1
            tot_surface_area=mag_c*0.5;
            count_c=count_c+1;
        else
            tot_surface_area=tot_surface_area+(mag_c*0.5);
        end
    
        %clear statements
        clear A; clear B; clear C; clear mag_c;
        
    end
    %clear statements
    clear x1; clear y1; clear z1; 
    clear x2; clear y2; clear z2;
    clear x3; clear y3; clear z3;
    
    
end
