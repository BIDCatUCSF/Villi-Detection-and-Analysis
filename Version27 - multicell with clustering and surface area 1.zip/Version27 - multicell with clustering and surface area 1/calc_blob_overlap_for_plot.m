function[block1_ret]=calc_blob_overlap_for_plot(pr,pg,ns,ne,block1)

%This function adds colocalization percentages to blobs that colocalize
%blocks 1 and 2 => These are the good and medium colocalizers.
%the bad colocalizers are assigned a colocalization percentage of '0'

%clear all; close all;

%inputs 
%pg = path to green cluster images
%pr = path to red cluster images
%ns, ne, => image indices
%block1 = list of overlapping blobs
%block1(:,1) = green cluster numbers
%block1(:,2) = red cluster numbers

%pg='G:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI45\ROI45 Latest Latest Clustering\Registered\g0\WholeImageStackClustering\Intensity Stack\Im';
%pr='G:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI45\ROI45 Latest Latest Clustering\Registered\r0\WholeImageStackClustering\Intensity Stack\Im';

%image indices - ROI45
%ns=30;
%ne=65;

%blocks of blobs - ROI45
%block1=[51,42;55,65;55,66;55,76;68,89;113,79];
%block2=[3,11;3,41;5,45;5,62;6,6;6,8;6,32;6,58;16,18;16,22;16,54;16,55;16,60;16,69;16,82;17,29;17,35;17,75;17,77;17,88;18,90;21,10;26,20;26,40;26,62;26,73;29,12;29,37;29,43;29,46;29,53;38,31;42,9;43,39;43,70;45,92;50,30;60,3;63,98;64,81;66,15;73,95;80,12;80,25;86,57;91,83;99,33;99,56;102,13;102,28;110,36;115,44;58,19];
%block3=[[2,4;2,27;7,38;8,68;8,71;8,72;9,23;9,27;11,7;11,24;13,48;14,48;20,24;20,47;23,51;24,61;27,78;27,97;28,52;35,47;36,21;36,34;37,4;37,38;37,84;39,50;44,34;44,96;46,4;49,7;49,63;52,21;53,87;53,94;56,16;56,26;56,38;57,67;57,74;59,14;59,49;61,68;70,5;74,27;75,34;76,85;77,5;77,59;78,14;79,91;82,71;84,26;85,27;87,64;89,5;90,49;94,63;95,63;100,49;103,94;104,27;107,27;107,34;109,93;112,91]];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%The Code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%Colocalization Data%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counters
countA=1;
countB=1;
ns
ne
for r=ns:ne
    
    %read in images
    img=imread(strcat(pg,num2str(r),'.tif'));
    imr=imread(strcat(pr,num2str(r),'.tif'));
    img=double(img);
    imr=double(imr);
    
    %non_zero entries
    idx_g=find(img>0);
    idx_r=find(imr>0);
    
    %green clusters
    if numel(idx_g)>0
        
        %convert to coordinates
        [yg,xg]=ind2sub(size(img),idx_g);
        zg=linspace(r,r,numel(yg))';
        
        if countA==1
            gr_clust_all=[img(idx_g),xg,yg,zg];
        else
            gr_clust_all_tmp=gr_clust_all;
            clear gr_clust_all;
            gr_clust_all=[gr_clust_all_tmp;[img(idx_g),xg,yg,zg]];
            clear gr_clust_all_tmp;
        end
        
        %iterate counter
        countA=countA+1;
        
        %clear statements
        clear xg; clear yg; clear zg;
        
    end
    
    %red clusters
    if numel(idx_r)>0
        
        %convert to coordinates
        [yr,xr]=ind2sub(size(imr),idx_r);
        zr=linspace(r,r,numel(yr))';
        
        if countB==1
            red_clust_all=[imr(idx_r),xr,yr,zr];
        else
            red_clust_all_tmp=red_clust_all;
            clear red_clust_all;
            red_clust_all=[red_clust_all_tmp;[imr(idx_r),xr,yr,zr]];
            clear red_clust_all_tmp;
        end
        
        %iterate counter
        countB=countB+1;
        
        %clear statements
        clear xr; clear yr; clear zr;
    end
    
    %clear statements
    clear img; clear imr; clear idx_g; clear idx_r; 
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Block 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%creating return
block1_ret=block1;
block1_ret(:,3)=zeros(numel(block1(:,1)),1); %pre-allocating for colocalization percentage
block1_ret(:,4)=zeros(numel(block1(:,1)),1); 

%cluster extrema - green
min1g=min(block1(:,1));
max1g=max(block1(:,1));

%cluster extrema - red
min1r=min(block1(:,2));
max1r=max(block1(:,2));

%counters (flags) 
count_g=1;
count_r=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%get green multiples
for i=min1g:max1g
   
    %look for cluster
    idx1=find(block1(:,1)==i);
    
    if numel(idx1)>1

        %get colocalizing clusters
        gr_mul_now(:,1)=block1(idx1,1);
        gr_mul_now(:,2)=block1(idx1,2);
        gr_mul_now(:,3)=block1_ret(idx1,3);
        gr_mul_now(:,4)=block1_ret(idx1,4);
        
        %get colocalization percentage
        [coloc_per_ret]=blob_final_mat_output(gr_mul_now,gr_clust_all,red_clust_all);
        
        %adding colocalization information to matrix
        block1_ret(idx1,3)=linspace(coloc_per_ret,coloc_per_ret,numel(idx1))';
        block1_ret(idx1,4)=linspace(1,1,numel(idx1))';
        
        %clear statements
        clear gr_mul_now;
 
    end
    
    %clear statements
    clear idx1;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%get the red multiples 
for r=min1r:max1r

    %look for cluster
    idx1A=find(block1(:,2)==r);
    
    if numel(idx1A)>1
        
        %get colocalizing clusters
        red_mul_now(:,1)=block1(idx1A,1);
        red_mul_now(:,2)=block1(idx1A,2);
        red_mul_now(:,3)=block1_ret(idx1A,3);
        red_mul_now(:,4)=block1_ret(idx1A,4);
        
        %get colocalization percentage
        [coloc_per_retA]=blob_final_mat_output(red_mul_now,gr_clust_all,red_clust_all);
        
        %adding colocalization information to matrix
        block1_ret(idx1A,3)=linspace(coloc_per_retA,coloc_per_retA,numel(idx1A))';
        block1_ret(idx1A,4)=linspace(1,1,numel(idx1A))';
        
        %clear statements
        clear red_mul_now;
        
    end
    
    %clear statements
    clear idx1A;

end

%get the rest 
idx_the_rest=find(block1_ret(:,4)==0);

if numel(idx_the_rest)>0
    for g=1:numel(idx_the_rest)
        %get colocalization percentage
        [coloc_per_retB]=blob_final_mat_output(block1_ret(idx_the_rest(g),:),gr_clust_all,red_clust_all);
        block1_ret(idx_the_rest(g),3)=coloc_per_retB;
        block1_ret(idx_the_rest(g),4)=1;
    end
end

