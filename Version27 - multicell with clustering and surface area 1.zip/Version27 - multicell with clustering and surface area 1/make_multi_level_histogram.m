function[]=make_multi_level_histogram(ncurve,ncluster)

%bins of histogram
nbins=linspace(-0.5,0.5,11);

%counter
count=1;
count2=1;

for i=1:numel(ncurve(:,1))
   
    %leaving out the intersections of hills and valleys - for now
    if ncurve(i,4) ~= 0
        n_all_curve_use(count,1)=ncurve(i,1);
        n_all_curve_use(count,2)=ncurve(i,2);
        n_all_curve_use(count,3)=ncurve(i,3);
        n_all_curve_use(count,4)=ncurve(i,4);
    
        if ncluster(i,4) > 0
            
            %keeping curvatures within clusters
            ncluster_use(count2,1)=ncluster(i,1);
            ncluster_use(count2,2)=ncluster(i,2);
            ncluster_use(count2,3)=ncluster(i,3);
            ncluster_use(count2,4)=ncurve(i,4);
            
            %iterate counter
            count2=count2+1;
        end
    
        %iterate counter
        count=count+1;
        
    end

end

%histograms - curvature
[y_curve,x_curve]=hist(n_all_curve_use(:,4),nbins);
[y_clust,x_clust]=hist(ncluster_use(:,4),nbins);

% figure, hold on
% plot(x_curve,y_curve,'ro');
% plot(x_clust,y_clust,'go');

%bar plot
for j=1:numel(y_clust)
   
    if j==1 
        ybar=[y_clust(j),y_curve(j)-y_clust(j)];
    else
        ybar_tmp=ybar;
        clear ybar;
        ybar=[ybar_tmp;[y_clust(j),y_curve(j)-y_clust(j)]];
        clear ybar_tmp;
    end
    
end
figure, bar(ybar,'stacked'); legend('In Cluster','Not in Cluster'); 
xticklabels({num2str(nbins(1)),num2str(nbins(2)),num2str(nbins(3)),num2str(nbins(4)),num2str(nbins(5)),num2str(nbins(6)),num2str(nbins(7)),num2str(nbins(8)),num2str(nbins(9)),num2str(nbins(10)),num2str(nbins(11))});
xlabel('Mean Curvature');
ylabel('# of Nodes in Surface');














