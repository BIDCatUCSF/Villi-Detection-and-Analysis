function[sa_thresh_arr,int_thresh_arr,curve_thr_excel]=get_stats_curve_thresh(node_cluster_thresh,mat_hist)

%making histograms
idx1_nz=find(node_cluster_thresh(:,4)>0);
min_nz1=min(node_cluster_thresh(idx1_nz,4));
max_nz1=max(node_cluster_thresh(idx1_nz,4));

%counter
count1=1;

for r=min_nz1:max_nz1
    
    %verify that cluster is there
    idx1=find(node_cluster_thresh(:,4)==r);
    
    if numel(idx1)>0
        
        %look in original statistics
        idx1_a=find(mat_hist(:,1)==r);
        
        if numel(idx1_a)>0
            
            %arrays for histograms
            sa_thresh_arr(count1,1)=mat_hist(idx1_a(1),2);
            int_thresh_arr(count1,1)=mat_hist(idx1_a(1),3);
            
            %matrix for later excel file-saving
            curve_thr_excel(count1,1)=mat_hist(idx1_a(1),1);
            curve_thr_excel(count1,2)=mat_hist(idx1_a(1),2);
            curve_thr_excel(count1,3)=mat_hist(idx1_a(1),3);
            curve_thr_excel(count1,4)=mat_hist(idx1_a(1),4);
            curve_thr_excel(count1,5)=mat_hist(idx1_a(1),5);
            
            %iterate counter
            count1=count1+1;
        end
        
        %clear statements
        clear idx1_a;
    end
    
    %clear statements
    clear idx1;
    
end





























