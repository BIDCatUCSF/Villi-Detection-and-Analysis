function[in_arr_ret,counterA]=find_same_elements(in_arr,d,counterA)

%declaring matrix to return
in_arr_ret=in_arr;

%sectioning out part of matrix
idx_other=find(in_arr(:,4)~=d);
other_arr(:,1)=in_arr(idx_other,1); %x
other_arr(:,2)=in_arr(idx_other,2); %y
other_arr(:,3)=in_arr(idx_other,3); %z
other_arr(:,4)=in_arr(idx_other,7); %position in original matrix

%sectionin out another part of matrix
idx_in=find(in_arr(:,4)==d);
the_arr(:,1)=in_arr(idx_in,1);
the_arr(:,2)=in_arr(idx_in,2);
the_arr(:,3)=in_arr(idx_in,3);
the_arr(:,4)=in_arr(idx_in,7);
the_arr(:,5)=in_arr(idx_in,8); 

for i=1:numel(the_arr(:,1))
   
    %seeing if there is a duplicate 
    if the_arr(i,5)==0
        diff_it=((the_arr(i,1)-other_arr(:,1))+(the_arr(i,2)-other_arr(:,2))+(the_arr(i,3)-other_arr(:,3)));
        idx_diff=find(diff_it==0);
        if numel(idx_diff)>0
                in_arr_ret(other_arr(idx_diff,4),8)=counterA;
                in_arr_ret(the_arr(i,4),8)=counterA;
                counterA=counterA+1;
        end
    end
        
    %clear statemetns
    clear diff_it; clear idx_diff;
    
end



































