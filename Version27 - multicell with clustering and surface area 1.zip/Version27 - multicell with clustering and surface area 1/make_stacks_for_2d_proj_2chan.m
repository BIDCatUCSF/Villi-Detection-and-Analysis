function[]=make_stacks_for_2d_proj_2chan(x1,y1,z1,c1,x2,y2,z2,c2,i1,i2,ns,ne,i_size,path_file_tay)


%PSF
PSF=fspecial('gaussian',5,10);
dp1=size(PSF,1);
dp2=size(PSF,2);
minp=min(PSF(1:(dp1*dp2)));
maxp=max(PSF(1:(dp1*dp2)));
PSF=PSF-minp;
PSF=PSF.*(1/(maxp-minp));

%green channel
x1=uint16(x1); 
y1=uint16(y1); 
z1=uint16(z1); 

%red channel
x2=uint16(x2); 
y2=uint16(y2); 
z2=uint16(z2); 

%pre-allocating image stack
dim1=size(i_size,1)
dim2=size(i_size,2)
gr_int_stack=uint16(zeros(dim1,dim2,ne-ns+1));
gr_curve_stack=uint16(zeros(dim1,dim2,ne-ns+1));
gr_mask_stack=uint16(zeros(dim1,dim2,ne-ns+1));
red_int_stack=uint16(zeros(dim1,dim2,ne-ns+1));
red_curve_stack=uint16(zeros(dim1,dim2,ne-ns+1));
red_mask_stack=uint16(zeros(dim1,dim2,ne-ns+1));

%ocunter
count_b=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%making the image stacks and doing convolution%%%%%%%%%%%%%%

for i=1:(ne-ns+1)

    %make blank images - curvature
    gc_im=uint16(zeros(size(i_size)));
    rc_im=uint16(zeros(size(i_size)));
    
    %make the blank images - intensity
    gi_im=uint16(zeros(size(i_size)));
    ri_im=uint16(zeros(size(i_size)));
    
    
    %get green curvature
    idx_gr_look=find(z1==i);
    xg=x1(idx_gr_look);
    yg=y1(idx_gr_look);
    cg=c1(idx_gr_look);
    int_g=i1(idx_gr_look);
    idx_g=sub2ind(size(gc_im),yg,xg);
    
    %get the red curvature
    idx_red_look=find(z2==i);
    xr=x2(idx_red_look);
    yr=y2(idx_red_look);
    cr=c2(idx_red_look); 
    int_r=i2(idx_red_look);
    idx_r=sub2ind(size(rc_im),yr,xr);
    
    %screening the curvature - FOR 2D RENDERING PURPOSES - (SCALE BAR)
    idx_high_g=find(cg>0.5);
    idx_low_g=find(cg<-0.5);
    if numel(idx_high_g)>0
        cg(idx_high_g)=0.5;
    end
    if numel(idx_low_g)>0
        cg(idx_low_g)=-0.5;
    end
    
    idx_high_r=find(cr>0.5);
    idx_low_r=find(cr<-0.5);
    if numel(idx_high_r)>0
        cr(idx_high_r)=0.5;
    end
    if numel(idx_low_r)>0
        cr(idx_low_r)=-0.5;
    end

    %the curvature - offset and scaled
    gc_im(idx_g)=cg+0.5;
    gc_im=(gc_im).*1000;
    rc_im(idx_r)=cr+0.5;
    rc_im=(rc_im).*1000;
    
    %The intensity
    gi_im(idx_g)=int_g;
    ri_im(idx_r)=int_r;

    %convolution - curvature
    gc_im_conv_tmp=imfilter(double(gc_im),PSF,'conv');
    rc_im_conv_tmp=imfilter(double(rc_im),PSF,'conv');
    
    %cropping
    gc_im_conv=imcrop(gc_im_conv_tmp,[1,1,dim2-1,dim1-1]);
    rc_im_conv=imcrop(rc_im_conv_tmp,[1,1,dim2-1,dim1-1]);
    
    %median filter
%     gc_im_conv=medfilt2(gc_im_conv,[2 2]);
%     rc_im_conv=medfilt2(rc_im_conv,[2 2]);
    
    %convolution - intensity
    gi_im_conv_tmp=imfilter(double(gi_im),PSF,'conv');
    ri_im_conv_tmp=imfilter(double(ri_im),PSF,'conv');
    
    gi_im_conv=imcrop(gi_im_conv_tmp,[1,1,dim2-1,dim1-1]);
    ri_im_conv=imcrop(ri_im_conv_tmp,[1,1,dim2-1,dim1-1]);
    
    %median filter
%     gi_im_conv=medfilt2(gi_im_conv,[2 2]);
%     ri_im_conv=medfilt2(ri_im_conv,[2 2]);

    %the mask
    g_mask=uint16(zeros(size(gc_im_conv)));
    r_mask=uint16(zeros(size(rc_im_conv)));
    idxgm=find(gc_im_conv>0);
    idxrm=find(rc_im_conv>0);
    g_mask(idxgm)=1;
    r_mask(idxrm)=1;
    
    %load the stacks
    count_b
    size(gi_im_conv)
    gr_int_stack(:,:,count_b)=gi_im_conv;
    gr_curve_stack(:,:,count_b)=gc_im_conv;
    gr_mask_stack(:,:,count_b)=g_mask;
    red_int_stack(:,:,count_b)=ri_im_conv;
    red_curve_stack(:,:,count_b)=rc_im_conv;
    red_mask_stack(:,:,count_b)=r_mask;
    
    %iterate counter
    count_b=count_b+1;

    %clear statements
    clear gc_im; clear rc_im;clear gi_im; clear ri_im;
    clear idx_gr_look; clear xg; clear yg; clear cg; 
    clear int_g; clear idx_g;
    clear idx_red_look; clear xr; clear yr; clear cr;
    clear int_r; clear idx_r;
    clear gc_im_conv; clear rc_im_conv;
    clear gi_im_conv; clear ri_im_conv;
    clear g_mask; clear r_mask;
    clear idxgm; clear idxrm;
    clear gc_im_conv_tmp; clear rc_im_conv_tmp;
    clear gi_im_conv_tmp; clear ri_im_conv_tmp;
    clear idx_high_g; clear idx_low_g;
    clear idx_high_r; clear idx_low_r;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%Saving the stacks%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%figuring out file and path for each stack - channel 1
green_int_name=strcat(path_file_tay,'_ch1_intensity_stack.tif')
green_curve_name=strcat(path_file_tay,'_ch1_curve_stack.tif')
green_mask_name=strcat(path_file_tay,'_ch1_mask_stack.tif')

%figuring out file and path for each stack - channel 2
red_int_name=strcat(path_file_tay,'_ch2_intensity_stack.tif')
red_curve_name=strcat(path_file_tay,'_ch2_curve_stack.tif')
red_mask_name=strcat(path_file_tay,'_ch2_mask_stack.tif')

%saving - channel 1
write_file(green_int_name,ne-ns+1,gr_int_stack)
write_file(green_curve_name,ne-ns+1,gr_curve_stack);
write_file(green_mask_name,ne-ns+1,gr_mask_stack);

%saving - channel 2
write_file(red_int_name,ne-ns+1,red_int_stack)
write_file(red_curve_name,ne-ns+1,red_curve_stack);
write_file(red_mask_name,ne-ns+1,red_mask_stack);

