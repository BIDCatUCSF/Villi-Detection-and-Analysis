function[bd_ret]=avg_bound(bd1,bd2,d1,d2,ct)

%This function returns the average boundary based on the two inputted
%boundaries bd1 and bd2

%The size of the returned boundary is based on the size of bd1

%making both boundaries doubles
bd1=double(bd1);
bd2=double(bd2);

%pre-allocating some space to speed things up
bd_ret=zeros(numel(bd1(:,1)),2);
bd_ret=double(bd_ret);

%calculating the mask
bw_cent=poly2mask(bd1(:,1),bd1(:,2),d1,d2);

%removing small objects that will confuse the centroid calculation
bw_cent_label=bwlabel(uint16(bw_cent));
min_cl=min(bw_cent_label(1:(d1*d2)));
max_cl=max(bw_cent_label(1:(d1*d2)));
count_cl=1;
for k=min_cl:max_cl
    
    idx_c=find(bw_cent_label==k);
    
    if numel(idx_c)>0 && bw_cent(idx_c(1))>0
        area_check(count_cl,1)=numel(idx_c);
        area_check(count_cl,2)=k;
        count_cl=count_cl+1;
    end
    
    clear idx_c;
    
end

%finding the largest object
large_o=max(area_check(:,1));
where_large=find(area_check(:,1)==large_o);
the_large_label=area_check(where_large(1),2);
bw_for_cent_calc=zeros(size(bw_cent));
bw_for_cent_calc=double(bw_for_cent_calc);
idx_large_o=find(bw_cent_label==the_large_label);
bw_for_cent_calc(idx_large_o)=1;

%calculating the centroid
s=regionprops(bw_for_cent_calc,'centroid');
center_now=s.Centroid

% figure, imagesc(bw_for_cent_calc); colormap(jet); colorbar;hold on;
% plot(center_now(1),center_now(2),'m+');

% %for debugging only
% if ct==123
%     figure, imagesc(bw_cent); colormap(jet); colorbar; title('122'); hold on;
%     the_19th=regionprops(bw_cent,'centroid')
%     c_plot=the_19th.Centroid;
%     plot(c_plot(1),c_plot(2),'g+');
% end

% if numel(s)==0
%     center_now=[bd1(1),bd1(2)]
% else
%     center_now=s.Centroid
% end

%angle calculation
[ang1]=calc_angle(bd1,center_now(2),center_now(1),bw_cent);
[ang2]=calc_angle(bd2,center_now(2),center_now(1),bw_cent);

%making the angle calc in degrees and not radians
ang1(:,3)=ang1(:,3)*(180/pi);
ang2(:,3)=ang2(:,3)*(180/pi);

%some sorting
ang1_tmp=ang1; 
clear ang1;
ang1=sortrows(ang1_tmp,3);


% 
% %for debugging only
% idx1=sub2ind(size(bw_cent),ang1(:,1),ang1(:,2));
% idx2=sub2ind(size(bw_cent),ang2(:,1),ang2(:,2));
% b1=zeros(size(bw_cent)); b1=double(b1);
% b2=zeros(size(bw_cent)); b2=double(b2);
% b1(idx1)=ang1(:,3);
% b2(idx2)=ang2(:,3);
% figure, imagesc(b1); colormap(jet); colorbar; hold on; title(num2str(ct)); 
% plot(center_now(1),center_now(2),'m+');
% figure, imagesc(b2); colormap(jet); colorbar; hold on; title(num2str(ct)); 
% plot(center_now(1),center_now(2),'m+');

%for debugging only 
% % figure, hold on; 
% % imagesc(bw_cent); colormap(gray); colorbar;
% % plot(center_now(1),center_now(2),'r+');

for k=1:numel(bd1(:,1))
   
    %calculate distance
    d_arr=ang1(k,3)-ang2(:,3);
    d_arr=abs(d_arr);
    
    %locate the coordinate in bd2 closest to bd1(k,:)
    low_dist=min(d_arr);
    
    %where is lowest point in bd2
    idx_low=find(d_arr==low_dist);
    
    %returning new boundary
    bd_ret_tmp(k,1)=mean([ang1(k,2),ang2(idx_low(1),2)]);
    bd_ret_tmp(k,2)=mean([ang1(k,1),ang2(idx_low(1),1)]);
    
    %clear statements
    clear d_arr; clear low_dist; clear idx_low;
    
    
end

%some sorting to make the masking work better
[bd_ret_ang]=calc_angle(bd_ret_tmp,center_now(2),center_now(1),bw_cent);
bd_ret_sort=sortrows(bd_ret_ang,3);
bd_ret(:,1)=bd_ret_sort(:,2);
bd_ret(:,2)=bd_ret_sort(:,1);

%This figure was for debugging only
% figure, hold on;
% plot(bd_ret(:,1),bd_ret(:,2),'k+','LineWidth',1.5); title(num2str(ct));
% plot(bd1(:,1),bd1(:,2),'r+','LineWidth',1.5);
% plot(bd2(:,1),bd2(:,2),'g+','LineWidth',1.5);
% 
% plot(bd_ret(:,1),bd_ret(:,2),'k','LineWidth',1.5); 
% plot(bd1(:,1),bd1(:,2),'r','LineWidth',1.5);
% plot(bd2(:,1),bd2(:,2),'g','LineWidth',1.5);















