clear all; close all;


m=10;
b=3;

x=linspace(1,100,100)';
y=(m*x)+b;

f=fit(x,y,'poly1');


%calculating rsquare
y_fit=(x.*f.p1)+(f.p2);
s=regstats(y,y_fit,'linear','rsquare');
the_r2=s.rsquare












