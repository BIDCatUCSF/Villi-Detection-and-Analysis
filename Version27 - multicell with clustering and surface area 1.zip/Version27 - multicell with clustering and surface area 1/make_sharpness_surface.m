function[sharp_2d_return]=make_sharpness_surface(base_area_2d,height_2d)

%This is a function written to make sharpness surfaces

%inputs are 2d projections

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%Code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%return projection
dim1=size(base_area_2d,1);
dim2=size(base_area_2d,2);
sharp_2d_return=zeros(dim1,dim2);
sharp_2d_return=double(sharp_2d_return);

%get non-zero entries
idx_ba=find(base_area_2d>0);
all_ba=base_area_2d(idx_ba);
all_h=height_2d(idx_ba);

%creating output
sharp_2d_return(idx_ba)=all_h./all_ba;




















