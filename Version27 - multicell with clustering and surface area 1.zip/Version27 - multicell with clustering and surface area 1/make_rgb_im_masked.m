function[the_rgb_im]=make_rgb_im_masked(im_start,im_mask,min_num,max_num,the_map,is_curve)

%image properties
im_start=double(im_start);
im_mask=double(im_mask);
idx_mask=find(im_mask>0);

if is_curve==1
    idx_b1=find(im_start>=0.5);
    idx_b2=find(im_start<=-0.5);
    if numel(idx_b1)>0
        im_start(idx_b1)=0.5;
    end
    if numel(idx_b2)>0
        im_start(idx_b2)=-0.5;
    end

    im_start=im_start+0.5;
    im_start=im_start.*100;
    
    min_num=0;
    max_num=100;

end


if is_curve==2
    idx_b1=find(im_start>=0.5);
    idx_b2=find(im_start==-0.6);
    if numel(idx_b1)>0
        im_start(idx_b1)=0.5;
    end
    if numel(idx_b2)>0
        im_start(idx_b2)=-0.5;
    end

    im_start=im_start+0.5;
    im_start=im_start.*100;
    
    min_num=0;
    max_num=100;

end


%mask image
bw_im=zeros(size(im_start));
bw_im(idx_mask)=1;

%intensity extrema
max_num=double(max_num)
min_num=double(min_num)
max_num=max_num-min_num;
im_start=im_start-min_num;

%scaling
if is_curve>0
    im_start=im_start.*(64/max_num);
else
    im_start=im_start.*(256/max_num);
end

%rgb rendering
the_rgb_im_tmp=ind2rgb(uint16(im_start),the_map);

%coloring the mask
bw_map=[[0,0,0];[1,1,1]];
bw_im_rgb=ind2rgb(uint16(bw_im),bw_map);

the_rgb_im(:,:,1)=the_rgb_im_tmp(:,:,1).*bw_im_rgb(:,:,1);
the_rgb_im(:,:,2)=the_rgb_im_tmp(:,:,2).*bw_im_rgb(:,:,2);
the_rgb_im(:,:,3)=the_rgb_im_tmp(:,:,3).*bw_im_rgb(:,:,3);

