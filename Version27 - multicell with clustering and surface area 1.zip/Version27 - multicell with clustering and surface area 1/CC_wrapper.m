function[C_ret,x_max,y_max]=CC_wrapper(imA,imB)

C=CrossCorrelation(imA,imB);
dimT=size(C,1);
dimS=size(C,2);

min_C=min(C(1:(dimT*dimS)));
max_C=max(C(1:(dimT*dimS)));

C=C-min_C;
max_C=max_C-min_C;

C_ret=C.*(1000/max_C);

the_final_max=max(C_ret(1:(dimT*dimS)));
idx_max=find(C_ret==the_final_max);

[y_max,x_max]=ind2sub(size(C_ret),idx_max(1));


