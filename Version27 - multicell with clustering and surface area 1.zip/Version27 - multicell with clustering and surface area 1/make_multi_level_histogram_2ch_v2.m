function[]=make_multi_level_histogram_2ch_v2(ncurve1,ncurve2,ncluster2,a_title)

%bins of histogram
nbins=linspace(-0.5,0.5,11);

%counter
count=1;
count2=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Getting the curvature for the entire surface%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%of input surface 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for q=1:numel(ncurve1(:,1))
   
    %leaving out the intersections of hills and valleys - for now
    if ncurve1(q,4) ~= 0
        
        n_all_curve_use1(count,1)=ncurve1(q,1);
        n_all_curve_use1(count,2)=ncurve1(q,2);
        n_all_curve_use1(count,3)=ncurve1(q,3);
        n_all_curve_use1(count,4)=ncurve1(q,4);
    
        %iterate counter
        count=count+1;
        
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Getting the curvature for the entire surface%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%of input surface 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for p=1:numel(ncurve2(:,1))
   
    %leaving out the intersections of hills and valleys - for now
    if ncurve2(p,4) ~= 0
        
        n_all_curve_use2(count2,1)=ncurve2(p,1);
        n_all_curve_use2(count2,2)=ncurve2(p,2);
        n_all_curve_use2(count2,3)=ncurve2(p,3);
        n_all_curve_use2(count2,4)=ncurve2(p,4);
    
        %iterate counter
        count2=count2+1;
        
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%Getting the curvature from the clusters%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%of surface 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter 
count3=1;

%cluster extrema
min_c=1;
max_c=max(ncluster2(:,4));

for k=min_c:max_c
   
    %get a cluster
    idx1=find(ncluster2(:,4)==k);
    
    if numel(idx1)>0
        
        for r=1:numel(idx1)
           
            %get a coordinate
            xa=ncluster2(idx1(r),1);
            ya=ncluster2(idx1(r),2);
            za=ncluster2(idx1(r),3);
            
            %finding distance to the other surface
            dist_arr=(((xa-n_all_curve_use1(:,1)).^2)+((ya-n_all_curve_use1(:,2)).^2)+((za-n_all_curve_use1(:,3)).^2)).^0.5;
            
            %finding the minimum distance
            idx_d_now=find(dist_arr==min(dist_arr));
            
            %curvature from surface 1 that is in clusters of surface 2
            curvature_1_in_2(count3,1)=n_all_curve_use1(idx_d_now(1),1);
            curvature_1_in_2(count3,2)=n_all_curve_use1(idx_d_now(1),2);
            curvature_1_in_2(count3,3)=n_all_curve_use1(idx_d_now(1),3);
            curvature_1_in_2(count3,4)=n_all_curve_use1(idx_d_now(1),4);
            
            %iterate counter
            count3=count3+1;
            
            %clear statements
            clear xa; clear ya; clear za; clear dist_arr; clear idx_d_now;
            
        end
        
    end
    
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%Making the histogram%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%histograms - curvature
[y_curve,x_curve]=hist(n_all_curve_use2(:,4),nbins);
[y_clust,x_clust]=hist(curvature_1_in_2(:,4),nbins);

%debugging
% figure, hold on
% plot(x_curve,y_curve,'ro');
% plot(x_clust,y_clust,'go');

%bar plot
for j=1:numel(y_clust)
    
    if j==1
        ybar=[y_clust(j),y_curve(j)];
    else
        ybar_tmp=ybar;
        clear ybar;
        ybar=[ybar_tmp;[y_clust(j),y_curve(j)]];
        clear ybar_tmp;
    end
    
end
figure, bar(ybar); legend('In Cluster','All (whole surface)'); title(a_title);
xticklabels({num2str(nbins(1)),num2str(nbins(2)),num2str(nbins(3)),num2str(nbins(4)),num2str(nbins(5)),num2str(nbins(6)),num2str(nbins(7)),num2str(nbins(8)),num2str(nbins(9)),num2str(nbins(10)),num2str(nbins(11))});
xlabel('Mean Curvature');
ylabel('# of Nodes in Surface');














