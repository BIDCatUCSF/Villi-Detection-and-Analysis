function[villus_flat_return]=get_pts_around_villus_for_fit_final(villus_pts_nc,n1,f1)

%This is a function written to find the flat points around a villus to fit
%a plane to. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%adding curvature to input matrix%%%%%%%%%%%%%%%%%%%%%%%%%%%

%new matrix
villus_pts=villus_pts_nc;

for t=1:numel(villus_pts_nc(:,1))
    
    %distance calculation
    dt=(n1(:,1)-villus_pts_nc(t,1))+(n1(:,2)-villus_pts_nc(t,2))+(n1(:,3)-villus_pts_nc(t,3));
    idx_dt=find(dt==0);
    
    %adding curvature
   villus_pts(t,4)=n1(idx_dt(1),4);
    
    
    %clear statements 
    clear dt; clear idx_dt;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Grab (3) or 4 points of villus that are the flattest%%%%%%%%%%%%

%sorting
villus_pts_sort=sortrows(villus_pts,4);

if numel(villus_pts_sort(:,1))>4
    for i=1:4
        villus_flat_tmp(i,1)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,2);
        villus_flat_tmp(i,2)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,1);
        villus_flat_tmp(i,3)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,3);
        villus_flat_tmp(i,4)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,4);
    end
else
    for i=1:3
        villus_flat_tmp(i,1)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,2);
        villus_flat_tmp(i,2)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,1);
        villus_flat_tmp(i,3)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,3);
        villus_flat_tmp(i,4)=villus_pts_sort(numel(villus_pts_sort(:,1))+1-i,4);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%Find coordinates in node and face matrices%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%to return%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



for j=1:numel(villus_flat_tmp(:,1))
    
   %locate node
   d_arr=(((n1(:,2)-villus_flat_tmp(j,1)).^2)+((n1(:,1)-villus_flat_tmp(j,2)).^2)+((n1(:,3)-villus_flat_tmp(j,3)).^2)).^0.5;
   idx=find(d_arr==0)
   
   %look in face matrix for the node
   idx1=find(f1(:,1)==idx);
   idx2=find(f1(:,2)==idx);
   idx3=find(f1(:,3)==idx);
   if numel(idx1)>0 || numel(idx2)>0 || numel(idx3)>0
      idx_all=[idx1;idx2;idx3];
   else 
       idx_all=[];
   end

   %make a list of all nodes that are connected to this point
   for k=1:numel(idx_all)
       if k==1
           node_circ=f1(idx_all(k),(1:3))';
       else
           node_circ_tmp=node_circ;
           clear node_circ;
           node_circ=[node_circ_tmp;f1(idx_all(k),(1:3))'];
           clear node_circ_tmp;
       end
   end
   
   %remove duplicate entries
   node_circ_unique=unique(node_circ,'rows');
   
   %get coordinates of unique node
   node_circ_coords=n1(node_circ_unique,:);

   %look around and see if any of these nodes are in the initial list
   for p=1:numel(villus_flat_tmp(:,1))
       if p~=j
           d_arr2=(((node_circ_coords(:,2)-villus_flat_tmp(p,1)).^2)+((node_circ_coords(:,1)-villus_flat_tmp(p,2)).^2)+((node_circ_coords(:,3)-villus_flat_tmp(p,3)).^2)).^0.5;
           idx_b2=find(d_arr2==0);
           if numel(idx_b2)>0
               node_circ_unique(idx_b2,:)=[];
               node_circ_coords(idx_b2,:)=[];
           end
           clear idx_b2; clear d_arr2;
       end
   end
   
    %pick the point whose curvature is closest to zero
    close_zero=min(abs(node_circ_coords(:,4)))
    node_circ_coords_abs=node_circ_coords;
    node_circ_coords_abs(:,4)=abs(node_circ_coords_abs(:,4));
    idx_close_zero=find(node_circ_coords_abs(:,4)==close_zero);
    
    %making return
    villus_flat_return_tmp(j,1)=node_circ_coords(idx_close_zero(1),1);
    villus_flat_return_tmp(j,2)=node_circ_coords(idx_close_zero(1),2);
    villus_flat_return_tmp(j,3)=node_circ_coords(idx_close_zero(1),3);
    villus_flat_return_tmp(j,4)=node_circ_coords(idx_close_zero(1),4);
   
   %clear statements
   clear d_arr; clear idx; clear idx1; clear idx2; clear idx3; clear idx_all;
   clear node_circ; clear node_circ_unique;clear node_circ_coords;
   clear close_zero; clear node_circ_coords_abs; clear idx_close_zero;
    
end


%making the matrix to return
villus_flat_return(:,1)=villus_flat_return_tmp(:,1);
villus_flat_return(:,2)=villus_flat_return_tmp(:,2);
villus_flat_return(:,3)=villus_flat_return_tmp(:,3);



























