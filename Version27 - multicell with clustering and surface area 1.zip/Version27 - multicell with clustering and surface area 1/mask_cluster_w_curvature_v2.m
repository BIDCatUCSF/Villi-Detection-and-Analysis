function[node_return,node_reverse_return]=mask_cluster_w_curvature_v2(ncurve1,ncluster1)

%This is the mask with clustering function to mask off the locations of
%clusters on curvature surfaces.
%It is for homogenous case. For example, this program masks clusters 
%from channel A on curvature from channel A. 

%make a new node matrix to return
node_return=ncurve1;

%making the mnimum -0.5
idx_too_low=find(node_return(:,4)<=-0.5);
if numel(idx_too_low)>0
    node_return(idx_too_low,4)=-0.5;
end

node_reverse_return=node_return;

idx_not_there=find(ncluster1(:,4)==0);
idx_there=find(ncluster1(:,4)>0);
node_return(idx_not_there,4)=-0.6;
node_reverse_return(idx_there,4)=-0.6;





