function[X,Y,Z,the_width,n_2,p_2]=fit_base_of_villus_wrapper(XYZ_2)



del_x=uint16(abs(max(XYZ_2(:,1))-min(XYZ_2(:,1))));
del_y=uint16(abs(max(XYZ_2(:,2))-min(XYZ_2(:,2))));
del_z=uint16(abs(max(XYZ_2(:,3))-min(XYZ_2(:,3))));
the_width_arr=[del_x;del_y;del_z];
the_width=max(the_width_arr)+12;

%compute the normal to the plane and a point that belongs to the plane
[n_2,V_2,p_2] = affine_fit(XYZ_2)

%what is the point on plane
%figure, plot3(p_2(1),p_2(2),p_2(3),'r+','MarkerSize',12,'LineWidth',1.5); title('Checking Fit');
% plot3(xc,yc,zc,'gx','MarkerSize',12,'LineWidth',2.5);


for i=1:the_width
    
    %figure out width from center - odd case and then even case
    if i==1
       % if mod(the_width,2)==1
            del_s1=(-1*double((uint16(the_width*0.5))))+1;
            del_s2=double(uint16(the_width*0.5));
%         else
%             del_s1=-(uint16(the_width*0.5))+1
%             del_s2=(uint16(the_width*0.5))
%         end
    end
    
     %making double
    del_s1=double(del_s1);
    del_s2=double(del_s2);
    the_width=double(the_width);
    i=double(i);

    %making the lists (S1 and S2)
    if i==1
        S2=linspace(del_s1+i-1,del_s1+i-1,the_width)';
        S1=linspace(del_s1,del_s2,the_width)';
    else
        S2_tmp=S2;
        clear S2;
        S2=[S2_tmp;linspace(del_s1+i-1,del_s1+i-1,the_width)'];
        clear S2_tmp;

        S1_tmp=S1;
        clear S1;
        S1=[S1_tmp;linspace(del_s1,del_s2,the_width)'];
        clear S1_tmp;
    end

end

%generate the pont coordinates
X = p_2(1)+[S1(:) S2(:)]*V_2(1,:)';
Y = p_2(2)+[S1(:) S2(:)]*V_2(2,:)';
Z = p_2(3)+[S1(:) S2(:)]*V_2(3,:)';