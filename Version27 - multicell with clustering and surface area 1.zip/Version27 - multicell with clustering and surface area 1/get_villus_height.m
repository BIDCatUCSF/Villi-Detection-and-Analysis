function[villus_ret]=get_villus_height(villus,the_plane,n,p)

%This function calculates the height of the villus at all points above the
%plane of interest

%inputs
%villus(:,1) = x coordinates of villus
%villus(:,2) = y coordinates of villus
%villus(:,3) = z coordinates of villus
%villus(:,4) = curvature

%the_plane(:,1) = x coordinates of plane along villus base
%the_plane(:,2) = y coordinates of plane along villus base
%the_plane(:,3) = z coordinates of plane along villus base

%n = 3 element vector - orthonormal basis vector
%p = point on plane


%some figures
% figure, hold on;
% plot3(villus(:,1),villus(:,2),villus(:,3),'g+','MarkerSize',15,'LineWidth',3);
% plot3(the_plane(:,1),the_plane(:,2),the_plane(:,3),'ro','MarkerSize',12,'LineWidth',5);

%pre-allocating matrix for height calculation
height_inter=zeros(numel(villus(:,1)),1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%Figuring out if points are above or below plane%%%%%%%%%%%%%%


for i=1:numel(villus(:,1))
   
    %distance to plane
    dist_arr=(((the_plane(:,1)-villus(i,1)).^2)+((the_plane(:,2)-villus(i,2)).^2)+((the_plane(:,3)-villus(i,3)).^2)).^0.5;
    min_dist=min(dist_arr);
    idx_min=find(dist_arr==min_dist);
    
    %define vector
    xclose=villus(i,1)-the_plane(idx_min(1),1);
    yclose=villus(i,2)-the_plane(idx_min(1),2);
    zclose=villus(i,3)-the_plane(idx_min(1),3);

    C=dot([xclose,yclose,zclose],p'.*n);
    if C<0
%         plot3(villus(i,1),villus(i,2),villus(i,3),'co','MarkerSize',15,'LineWidth',3);
        height_inter(i,1)=(-1)*min_dist;
    else
        height_inter(i,1)=min_dist;
    end

    %clear statements
    clear dist_arr; clear min_dist; clear idx_min;
    clear xclose; clear yclose; clear zclose;
    clear C;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Figure out the height%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%absolute minimum height
abs_min_height=min(height_inter(:,1));

%creating return
villus_ret=villus;
villus_ret(:,5)=height_inter(:,1)+abs(abs_min_height);











