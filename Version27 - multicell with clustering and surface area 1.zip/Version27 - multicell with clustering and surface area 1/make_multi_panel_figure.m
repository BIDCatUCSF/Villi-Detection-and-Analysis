function[]=make_multi_panel_figure(node_in,face_in)


%This is a function written to make a multi-panel figure describing villi
%of different heights, sizes, ... ,

%colormap
the_map=get_jet_map();

%get the non-zero values from the node
idx1=find(node_in(:,4)>0);
the_vals=node_in(idx1,4)
idx_k=kmeans(the_vals,3);

%making another matrix to tell me where clusters are
the_mat=zeros(numel(node_in(:,4)),1);
the_mat(idx1)=idx_k;

%node - cluster 1
node1=node_in;
idxc1=find(the_mat~=1);
node1(idxc1,4)=0;

%node - cluster 2
node2=node_in;
idxc2=find(the_mat~=2);
node2(idxc2,4)=0;

%node - cluster 3
node3=node_in;
idxc3=find(the_mat~=3);
node3(idxc3,4)=0;


figure, hold on; plotmesh(node1,face_in); shading interp; title('Cluster 1'); caxis([0,max(node_in(:,4))]); colormap(the_map); freezeColors;  colorbar; hold on;
figure, hold on; plotmesh(node2,face_in); shading interp; title('Cluster 2'); caxis([0,max(node_in(:,4))]); colormap(the_map); freezeColors;  colorbar; hold on;
figure, hold on; plotmesh(node3,face_in); shading interp; title('Cluster 3'); caxis([0,max(node_in(:,4))]); colormap(the_map); freezeColors;  colorbar; hold on;





























