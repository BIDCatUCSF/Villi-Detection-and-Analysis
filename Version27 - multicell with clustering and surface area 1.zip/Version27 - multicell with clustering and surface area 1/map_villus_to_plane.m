function[curvature_list,height_list]=map_villus_to_plane(xp,yp,zp,v_data)

%This is a function written to find the points on the 2d plane fit to
%villus base that correspond to the villus itself.

%inputs
%xp = x coordinates of plane
%yp = y coordinates of plane
%zp = z coordinates of plane

% v_data(:,1) = x coordinates
% v_data(:,2) = y coordinates
% v_data(:,3) = z coordinates
% v_data(:,4) = curvature
% v_data(:,5) = height

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%the code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%lists to return
height_list=zeros(numel(xp),1); height_list=double(height_list);
height_list=height_list-1000;
curvature_list=zeros(numel(xp),1); curvature_list=double(curvature_list);
curvature_list=curvature_list-1000;

%adding to the lists
for q=1:numel(v_data(:,1))
    
   %find closest distance to plane
   d_plane=(((xp-v_data(q,1)).^2)+((yp-v_data(q,2)).^2)+((zp-v_data(q,3)).^2)).^0.5;
   d_min=min(d_plane(:,1));
   idx_d_min=find(d_plane==d_min);
   
   %adding the height
   height_list(idx_d_min(1))=v_data(q,5);
   
   %adding the curvature
   curvature_list(idx_d_min(1))=v_data(q,4);
   
   %clear statements
   clear d_plane;
   clear d_min;
   clear idx_d_min;
    
end



























