function[mountain_or_not_ret]=find_grad_ring(angle_list,curvature_list,mountain_or_not_in,idx_ring1,idx_ring2)

%This is a function written to calculate the difference in cruvrature
%between coordinates in a given ring and coordinates in the ring
%immediately interior to that ring

%inputs
%angle list - list of angles relative to center position
%mountain_or_not - list of '1' or '0' if part of mountain or not
%idx_ring1 - indices of interior ring (in lists)
%idx_ring2 - indices of current ring (in lists)
%curvature_list - list of curvatures

%output
%mountain_or_not_ret - list of '1' or '0' if part of mountain or not
%In this case, it is populated to reflect ring 2 

%some definitions
r1_angles=angle_list(idx_ring1);
r1_curve=curvature_list(idx_ring1);
r1_mountain_or_not=mountain_or_not_in(idx_ring1);

%intializing return
mountain_or_not_ret=mountain_or_not_in;

for j=1:numel(idx_ring2)
    
    %get curvature and angle from ring 2
    r2_ang_now=angle_list(idx_ring2(j));
    r2_curv_now=curvature_list(idx_ring2(j));
    
    %find closest point in interior ring - by angle
    diff_ang=abs(r1_angles-r2_ang_now);
    min_ang_1=min(diff_ang);
    idx_min_ang=find(diff_ang==min_ang_1);
    curve_from_r1=r1_curve(idx_min_ang(1));
    
    %seeing if I am descending or not
%     if (curve_from_r1-r2_curv_now)<0 && r1_mountain_or_not(idx_min_ang(1))==1 && r2_curv_now<-0.05 && curve_from_r1<-0.5
%         mountain_or_not_ret(idx_ring2(j))=1;
%     elseif abs(curve_from_r1-r2_curv_now)<0.05 && r1_mountain_or_not(idx_min_ang(1))==1 && r2_curv_now<-0.05 && curve_from_r1<-0.5
%         mountain_or_not_ret(idx_ring2(j))=1; 
%     else
%         mountain_or_not_ret(idx_ring2(j))=0;
%     end

    if (curve_from_r1-r2_curv_now)<0 && r1_mountain_or_not(idx_min_ang(1))==1 && r2_curv_now<-0.00 && curve_from_r1<-1
        mountain_or_not_ret(idx_ring2(j))=1;
    elseif abs(curve_from_r1-r2_curv_now)<0.05 && r1_mountain_or_not(idx_min_ang(1))==1 && r2_curv_now<-0.00 && curve_from_r1<-1
        mountain_or_not_ret(idx_ring2(j))=1; 
    else
        mountain_or_not_ret(idx_ring2(j))=0;
    end

    
    %clear statements
    clear r2_ang_now; clear r2_curv_now; clear diff_ang;
    clear min_ang_1; clear idx_min_ang; clear curve_from_r1;
    
end
















































