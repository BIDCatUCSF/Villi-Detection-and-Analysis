clear all; close all;

%path
path='H:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI45\ROI45\g0\Final Microvilli Locs\';

%original surface
node_orig_tmp=load(strcat(path,'Nodes_curvature_for_villi.mat'));
node_orig=node_orig_tmp.n_curve1;
face_orig_tmp=load(strcat(path,'FaceMat_curvature_for_villi.mat'));
face_orig=face_orig_tmp.f_curve1;

%colormaps
[ens_curve_map,ens_curve_map_mask]=get_curvature_maps;

figure, plotmesh(node_orig,face_orig); shading faceted; title('Threshed Curvature'); caxis([-0.5,0.5]);colormap(ens_curve_map);  colorbar; hold on; %freezeColors; 

for i=1:10
    
    if i==1
       plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'g+','MarkerSize',12,'LineWidth',2.5);
       plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'g+','MarkerSize',12,'LineWidth',2.5);
       plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'g+','MarkerSize',12,'LineWidth',2.5);
    elseif i==2
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'r+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'r+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'r+','MarkerSize',12,'LineWidth',2.5);
    elseif i==3
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'y+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'y+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'y+','MarkerSize',12,'LineWidth',2.5);
    elseif i==4
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'b+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'b+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'b+','MarkerSize',12,'LineWidth',2.5);
    elseif i==5
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'k+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'k+','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'k+','MarkerSize',12,'LineWidth',2.5);
    elseif i==6
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'go','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'go','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'go','MarkerSize',12,'LineWidth',2.5);
    elseif i==7
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'ro','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'ro','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'ro','MarkerSize',12,'LineWidth',2.5);
    elseif i==8
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'yo','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'yo','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'yo','MarkerSize',12,'LineWidth',2.5);
    elseif i==9
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'bo','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'bo','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'bo','MarkerSize',12,'LineWidth',2.5);
    else
        plot3(node_orig(face_orig(i,1),1), node_orig(face_orig(i,1),2),node_orig(face_orig(i,1),3),'ko','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,2),1), node_orig(face_orig(i,2),2),node_orig(face_orig(i,2),3),'ko','MarkerSize',12,'LineWidth',2.5);
        plot3(node_orig(face_orig(i,3),1), node_orig(face_orig(i,3),2),node_orig(face_orig(i,3),3),'ko','MarkerSize',12,'LineWidth',2.5);
    end
    
end




