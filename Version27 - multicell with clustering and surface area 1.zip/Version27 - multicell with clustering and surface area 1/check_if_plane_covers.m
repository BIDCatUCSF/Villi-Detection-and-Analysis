function[pp]=check_if_plane_covers(xA,yA,zA,v1)

%inputs
% xA = x coordinates of plane
% yA = y coordinates of plane
% zA = z coordinates of plane
% v1 = villus coordinates

%coordinate extrema 
xmin=min(xA);
xmax=max(xA);

ymin=min(yA);
ymax=max(yA);

zmin=min(zA);
zmax=max(zA);

%total number of coordinates of villus
tot_v=numel(v1(:,1));

%counter
count=0;

for i=1:numel(v1(:,1))
    
    if v1(i,1)>=xmin && v1(i,1)<=xmax && v1(i,2)>=ymin && v1(i,2)<=ymax && v1(i,3)>=zmin && v1(i,3)<=zmax
        count=count+1;
    end
end

%percentage in plane
pp=100*(count/tot_v);


