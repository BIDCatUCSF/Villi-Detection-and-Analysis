function[cell_erode_avg,frame_list]=avg_erode_bound(p_er,p_bd,ns,ne)

%This is a function written to average the eroded boundary images to make
%2d projection easier.

%colormap
a_map=colormap(jet);

%counter
count_ash=1;

%structuring element for erosion
nhood=[0 1 0; 1 1 1; 0 1 0];

%creating a cell array to hold "averaged" image
cell_erode_avg=cell(ne-ns+1,2);

for t=ns:ne
    
   %reading in an eroded boundary image
   im_er=imread(strcat(p_er,num2str(t),'.tif'));
   im_er=double(im_er);

   %dimensions
   if count_ash==1
       dim1=size(im_er,1);
       dim2=size(im_er,2);
   end
   
   %loading the boundary
   bd_tmp=load(strcat(p_bd,num2str(t),'.mat'));
   bd=bd_tmp.boundary_out;

   %making a mask
   bw_im=poly2mask(bd(:,1),bd(:,2),dim1,dim2);

   %calculating centroid
   s=regionprops(bw_im,'centroid');
   cent_now=s.Centroid;

   %the erosion
   J = imerode(bw_im,nhood);
   J2 = imerode(J,nhood);
   J3 = imerode(J2,nhood);

   %calculate boudaries
%    figure, imagesc(im_er); colormap(gray); colorbar; hold on;
   
   bound_er1_tmp=bwboundaries(J);
   bound_er1=bound_er1_tmp{1};
   
   bound_er2_tmp=bwboundaries(J2);
   bound_er2=bound_er2_tmp{1};

   %foe debugging onluj
%    plot(bd(:,1),bd(:,2),'r');
%    plot(bound_er1(:,2),bound_er1(:,1),'g');
%    plot(bound_er2(:,2),bound_er2(:,1),'c');
%    
%    plot(bd(:,1),bd(:,2),'ro');
%    plot(bound_er1(:,2),bound_er1(:,1),'go');
%    plot(bound_er2(:,2),bound_er2(:,1),'co');
   
   %re-arranging bd matrix
   bd_tmp=bd;
   clear bd; 
   bd(:,1)=bd_tmp(:,2);
   bd(:,2)=bd_tmp(:,1);
   clear bd_tmp;
   
   %getting the angle for each position
   [giant_coord_list1]=calc_angle(bd,cent_now(1),cent_now(2),im_er);
   [giant_coord_list2]=calc_angle(bound_er1,cent_now(1),cent_now(2),im_er);
   [giant_coord_list3]=calc_angle(bound_er2,cent_now(1),cent_now(2),im_er);
   
   %doing the averaging
   for w=1:numel(bd(:,1))
       
       %make new image
       if w==1
           new_im=zeros(dim1,dim2);
           new_im=double(new_im);
       end
       
       %getting a coordinate and angle
       x1=giant_coord_list1(w,1);
       y1=giant_coord_list1(w,2);
       a1=giant_coord_list1(w,3);
       
       %differences in angle
       del2=abs(giant_coord_list2(:,3)-a1);
       del3=abs(giant_coord_list3(:,3)-a1);
       
       %minimizing difference in angle
       min_2=min(del2);
       min_3=min(del3);
       
       %locations of minima
       idx_min_2=find(del2==min_2);
       idx_min_3=find(del3==min_3);
       
       %coordinates from the two eroded boundaries (2 and 3)
       x2=giant_coord_list2(idx_min_2(1),1);
       y2=giant_coord_list2(idx_min_2(1),2);
       x3=giant_coord_list3(idx_min_3(1),1);
       y3=giant_coord_list3(idx_min_3(1),2);
       
       %converting coordinates to indices
       idx_d1=sub2ind(size(new_im),y1,x1);
       idx_d2=sub2ind(size(new_im),y2,x2);
       idx_d3=sub2ind(size(new_im),y3,x3);
       
       %making the new image
       new_im(idx_d1)=mean([im_er(idx_d1),im_er(idx_d2),im_er(idx_d3)]);
       
       %clear statements
       clear x1; clear y1; clear a1; clear del2; clear del3; 
       clear min_2; clear min_3; clear idx_min_2; clear idx_min_3;
       clear x2; clear y2; clear x3; clear y3; clear idx_d1; clear idx_d2;
       clear idx_d3;
       
   end
   
   
   
%    figure, imagesc(erode_mask); colormap(jet); colorbar; hold on; title('The Center');
%    plot(cent_now(1),cent_now(2),'m+','MarkerSize',12,'LineWidth',1.5);
   

 % figure, imagesc(new_im); colormap(gray); colorbar; title('Average Image');
  
  %store the averaged image
  cell_erode_avg(count_ash,1)={new_im};
  cell_erode_avg(count_ash,2)={t};
  
  %making a list of frame numbers
  frame_list(count_ash,1)=t;
  
  %iterate counter
  count_ash=count_ash+1;
    
  %clear statments
  clear bound_er1_tmp; clear bound_er1;
  clear bound_er2_tmp; clear bound_er2;
  clear J; clear J2; clear J3;clear s; clear cent_now;
  clear s; clear cent_now; clear bw_im;clear bd; clear bd_tmp;
  clear im_er;

end











