clear all; close all;


%This is a script written to make figure for talk only

%load file
load('villus_info_flat_surface.mat');

%curvature maps
[ens_curve_map,ens_curve_map_mask]=get_curvature_maps();

for g=1:1

    %get the height information
    the_arr_tmp=cell_flat(g,1);
    the_arr=the_arr_tmp{1};
    the_arr=abs(the_arr);
    hc_tmp=the_arr(:,5);
    
    idx_zero=find(the_arr(:,4)==1000);
    idx_good=find(the_arr(:,4)~=1000);
    
    the_arr=uint16(the_arr);
    [X,Y] = meshgrid(the_arr(:,1),the_arr(:,2));
    Z=zeros(size(X));
    Z=double(Z);
    
    
    xc=the_arr(idx_good,1);
    yc=the_arr(idx_good,2);
    xc=uint16(xc); yc=uint16(yc);
    hc=hc_tmp(idx_good);
    
    
    
    for i=1:size(X,1)
        for j=1:size(X,2)
            for p=1:numel(xc)
                if X(i,j)==xc(p) && Y(i,j)==yc(p)
                    Z(i,j)=hc(p);
                end
            end
            
        end
    end
    
    figure, surf(X,Y,Z); axis tight; shading interp; colormap(jet); title(num2str(g));
    
    clear the_arr_tmp; clear the_arr; clear hc_tmp; 
    clear idx_zero; clear idx_good; clear X; clear Y; clear Z;
    clear xc; clear yc; clear hc;

end











