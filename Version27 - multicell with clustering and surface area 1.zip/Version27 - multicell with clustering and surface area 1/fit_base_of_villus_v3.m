function[X1,Y1,Z1,n_ret,p_ret]=fit_base_of_villus_v3(XYZ_2_in,the_villus,the_nodes)

%This is the function that fits the base of the villus to a plane.
%Version 3 of this program has an optimization step to insure that the
%plane fits the base of villus accurately.

%In version 3, the optimization step involves optimization how well the
%plane is centered on the peak (1) and the maximization of the distance
%between the [center of t-cell,center of plane] and [center of
%t-cell,center of villus]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%finding the center of t cell%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% xcenter=mean(the_nodes(:,1));
% ycenter=mean(the_nodes(:,2));
% zcenter=mean(the_nodes(:,3));

%getting the local center of the t-cell surface
[xcenter,ycenter,zcenter]=find_local_center_of_cell(XYZ_2_in,the_nodes);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Examining the points associated with the villus%%%%%%%%%%%%%%%%

%locate peak
c_peak=min(the_villus(:,4));
idx_peak=find(the_villus(:,4)==c_peak);
x_peak=the_villus(idx_peak(1),1);
y_peak=the_villus(idx_peak(1),2);
z_peak=the_villus(idx_peak(1),3);

% %figure for debugging
% figure, hold on;
% plot3(the_nodes(:,1),the_nodes(:,2),the_nodes(:,3),'k+');
% plot3(xcenter,ycenter,zcenter,'r+','MarkerSize',20,'LineWidth',3);
% plot3(x_peak,y_peak,z_peak,'g+','MarkerSize',20,'LineWidth',3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%Fitting the flat points%%%%%%%%%%%%%%%%%%%%%%%%%%%

%the initial fitting
[X1,Y1,Z1,the_width1,n_ret,p_ret]=fit_base_of_villus_wrapper(XYZ_2_in);

%testing quality of fit - distance to peak
dist_peak=(((x_peak-X1).^2)+((y_peak-Y1).^2)+((z_peak-Z1).^2)).^0.5;
min_peak_dist=min(dist_peak);

%testing quality of fit - distance to flat part of villus
for k=1:numel(XYZ_2_in(:,1))

    %calculate distance
    dist_flat_tmp=(((XYZ_2_in(k,1)-X1).^2)+((XYZ_2_in(k,2)-Y1).^2)+((XYZ_2_in(k,3)-Z1).^2)).^0.5;
    dist_flat(k,1)=min(dist_flat_tmp);
    
    %clear statements
    clear dist_flat_tmp;
end


%initialize flag
flag=1;

%seeing if fit is bad
%4 has to be the minimal number of points to fit to.
if numel(XYZ_2_in(:,1))>4
    if mean(dist_flat(:,1))>min_peak_dist
        %fit is bad
        flag=0;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%refitting if necessary%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag==0
    
    %total number of elements
    tot_ele=numel(XYZ_2_in(:,1));
    
    %finding all of the unique combinations
    combos = combntns(1:tot_ele,4);
    
    %number of iterations in this case
    max_iter=numel(combos(:,1));
    
    %cell array to hold fit information
    cell_the_fit=cell(max_iter,6); %x,y and z
    
    for n=1:max_iter
        
        %clear original fit
        clear X1; clear Y1; clear Z1; clear the_width1;
        
        %getting some coordinates
        rn=combos(n,:);
        
        %coordinates to fit
        XYZ_2_new=XYZ_2_in(rn,:);
        clear rn;
        
        %fitting
        [X1,Y1,Z1,the_width1,n1,p1]=fit_base_of_villus_wrapper(XYZ_2_new);
        
        %store the fit
        cell_the_fit(n,1)={X1};
        cell_the_fit(n,2)={Y1};
        cell_the_fit(n,3)={Z1};
        cell_the_fit(n,4)={the_width1};
        cell_the_fit(n,5)={n1};
        cell_the_fit(n,6)={p1};
        
        %check how many points are over plane
        pp_ret=check_if_plane_covers(X1,Y1,Z1,the_villus);

        
        %checking distance from flat area
        clear dist_flat_tmp; clear dist_flat;
        for k=1:numel((XYZ_2_new(:,1)))
            
            %calculate distance
            dist_flat_tmp=(((XYZ_2_new(k,1)-X1).^2)+((XYZ_2_new(k,2)-Y1).^2)+((XYZ_2_new(k,3)-Z1).^2)).^0.5;
            dist_flat(k,1)=min(dist_flat_tmp);
            
            %clear statements
            clear dist_flat_tmp;
        end
        
        %testing quality of fit - distance to peak
        clear dist_peak; clear min_peak_dist;
        dist_peak=(((x_peak-mean(X1)).^2)+((y_peak-mean(Y1)).^2)+((z_peak-mean(Z1)).^2)).^0.5;
        min_peak_dist=min(dist_peak);
        
        %distance from center of t-cell to center of plane
        dist_tc1=(((xcenter-mean(X1)).^2)+((ycenter-mean(Y1)).^2)+((zcenter-mean(Z1)).^2)).^0.5;
        
        %distance from center of t-cell to peak
        dist_tc2=(((xcenter-x_peak).^2)+((ycenter-y_peak).^2)+((zcenter-z_peak).^2)).^0.5;
        
        %some curve fitting - why not?
        mxz=1/((x_peak-xcenter)/(z_peak-zcenter));
        myz=1/((y_peak-ycenter)/(z_peak-zcenter));
        the_off=z_peak-(mxz*x_peak)-(myz*y_peak);
        xtest=linspace(1,200,200)';
        ytest=linspace(1,200,200)';
        ztest=(mxz.*xtest)+(myz*ytest)+the_off;
        dist_test=(((mean(X1)-xtest).^2)+((mean(Y1)-ytest).^2)+((mean(Z1)-ztest).^2)).^0.5;

        %storing
        the_fit_data(n,1)=n;
        the_fit_data(n,2)=dist_tc2-dist_tc1; %vector distance
        the_fit_data(n,3)=min_peak_dist; %distance between center of plane and peak
        the_fit_data(n,4)=min(dist_test); %how close peak, center of plane and center of tcell align
        the_fit_data(n,5)=pp_ret; %percentage of points occupied by plane
        %clear statements
        clear dist_tc1; clear dist_tc2;
         clear mxz; clear myz; clear the_off; clear xtest; clear ytest; clear ztest; clear dist_test;
         
    end
    
    %clear the most current fit
    clear X1; clear Y1; clear Z1; clear the_width1;
    
    
    %get the actual fit that most closely matches - vector distance
    sort_fit_data_now=sortrows(the_fit_data,2);
    size(sort_fit_data_now)
    if numel(sort_fit_data_now(:,1))>5
        data_screen_2=sort_fit_data_now((numel(sort_fit_data_now(:,1))-5):(numel(sort_fit_data_now(:,1))),:);
    else
        data_screen_2=sort_fit_data_now((numel(sort_fit_data_now(:,1))-4):(numel(sort_fit_data_now(:,1))),:);
    end
    
    %get the actual fit that most closely matches
    data_screen_3_tmp=sortrows(data_screen_2,3);
    data_screen_3=data_screen_3_tmp(1:4,:);
    
    %getting the actual fit that most closely matches
    max_fill=max(data_screen_3(:,5));
    idx_best=find(data_screen_3(:,5)==max_fill);
    
    %get the fit
    X1_tmp=cell_the_fit(data_screen_3(idx_best(1),1),1); X1=X1_tmp{1};
    Y1_tmp=cell_the_fit(data_screen_3(idx_best(1),1),2); Y1=Y1_tmp{1};
    Z1_tmp=cell_the_fit(data_screen_3(idx_best(1),1),3); Z1=Z1_tmp{1};
    the_width1_tmp=cell_the_fit(data_screen_3(idx_best(1),1),4); the_width1=the_width1_tmp{1};
    n1f_tmp=cell_the_fit(data_screen_3(idx_best(1),1),5); n_ret=n1f_tmp{1};
    p1f_tmp=cell_the_fit(data_screen_3(idx_best(1),1),6); p_ret=p1f_tmp{1};
    
    %plots for debugging
%     figure, hold on; title('Hello');
%     plot3(the_nodes(:,1),the_nodes(:,2),the_nodes(:,3),'k+');
%     plot3(xcenter,ycenter,zcenter,'r+','MarkerSize',20,'LineWidth',3);
%     plot3(X1,Y1,Z1,'ro','MarkerSize',12);
%     plot3(x_peak,y_peak,z_peak,'g+','MarkerSize',20,'LineWidth',3);
    
%     figure, hold on; title('The Difference');
%     plot(the_fit_data(:,1),the_fit_data(:,3)-the_fit_data(:,2),'g','LineWidth',1.5);
%     plot(the_fit_data(idx_max,1),the_fit_data(idx_max,3)-the_fit_data(idx_max,2),'r+','LineWidth',1.5,'MarkerSize',12);
%     plot(the_fit_data(idx_min,1),the_fit_data(idx_min,3)-the_fit_data(idx_min,2),'k+','LineWidth',1.5,'MarkerSize',12);

john=100000

%     
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% %plot the plane on the surface%%%%%%%%%%%%%%%%%%%%%%%%

%plot3(X1,Y1,Z1,'ro','MarkerSize',12,'LineWidth',7);

 %surf(reshape(X1,the_width1,the_width1),reshape(Y1,the_width1,the_width1),reshape(Z1,the_width1,the_width1),'facecolor','blue','facealpha',0.9);


% xlabel('x'); 
% ylabel('y');
% zlabel('z');
% axis equal




















































