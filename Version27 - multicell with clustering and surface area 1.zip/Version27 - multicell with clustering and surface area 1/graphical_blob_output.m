function[]=graphical_blob_output(int_stack_gr,cl_stack_gr,int_stack_red,cl_stack_red,blob_matrix,blob_num)

%This is a function to  make 2d projections of image stack to show the
%extent of colocalized blobs in En's data.
%It makes colored RGB rendered 2d projections of colocalization and then
%highlights on those the extent to which clusters colocalize based on
%cluster and blob analysis

%inputs
% int_stack_gr = stack of green eroded images with avg boundary
% cl_stack_gr = stack of green cluster images
% int_stack_red = stack of red images with avg boundary
% cl_stack_red = stack of red cluster images

%NB - These are actual image stack (3d matrices)

%blob_matrix = matrix of blob colocalization
%blob_matrix(:,1) = green cluster numbers in blob
%blob_matrix(:,2) = red cluster numbers in blob
%blob_matrix(:,3) = percentage of colocalization

%blob_num = integer
%         = 1 - really good colocalizers >50%
%         = 2 - medium good colocalizers 30%->50%
%         = 3 - does not colocalize (<30%)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%The Code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%getting 2d projections 
[gr_int_2d_tmp,gr_cl_2d_tmp]=make_2d_projection(int_stack_gr,cl_stack_gr,blob_matrix(:,1));
[red_int_2d_tmp,red_cl_2d_tmp]=make_2d_projection(int_stack_red,cl_stack_red,blob_matrix(:,2));

%figures for debugging
% figure, imagesc(gr_int_2d_tmp); colormap(gray); colorbar; title('Green Intensity');
% figure, imagesc(gr_cl_2d_tmp); colormap(jet); colorbar; title('Green Clusters');
% figure, imagesc(red_int_2d_tmp); colormap(gray); colorbar; title('Red Intensity');
% figure, imagesc(red_cl_2d_tmp); colormap(jet); colorbar; title('Red Clusters');

%median filter
% gr_int_2d_tmp=medfilt2(gr_int_2d_tmp,[2 2]);
% gr_cl_2d_tmp=medfilt2(gr_cl_2d_tmp,[2 2]);
% red_int_2d_tmp=medfilt2(red_int_2d_tmp,[2 2]);
% red_cl_2d_tmp=medfilt2(red_cl_2d_tmp,[2 2]);

%dimensions of 2d projections
dim1g=size(gr_int_2d_tmp,1);
dim2g=size(gr_int_2d_tmp,2);
dim1r=size(red_int_2d_tmp,1);
dim2r=size(red_int_2d_tmp,2);

%getting smallest dimension
if dim2g<dim2r
    dim_small=dim2g;
else
    dim_small=dim2r;
end

%cropping to make same size
gr_int_2d=imcrop(gr_int_2d_tmp,[1,1,dim_small-1,dim1g-1,]);
red_int_2d=imcrop(red_int_2d_tmp,[1,1,dim_small-1,dim1r-1]);
gr_cl_2d=imcrop(gr_cl_2d_tmp,[1,1,dim_small-1,dim1g-1,]);
red_cl_2d=imcrop(red_cl_2d_tmp,[1,1,dim_small-1,dim1r-1]);

% %binary images
b1=zeros(size(gr_int_2d));
b2=b1;
idx1=find(gr_int_2d>0);
b1(idx1)=1;
idx2=find(red_int_2d>0);
b2(idx2)=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%Registration%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%cross-correlation
[C_ret,x_max,y_max]=CC_wrapper(gr_int_2d,red_int_2d);

%dimensions
dimA=size(gr_int_2d,1);
dimB=size(gr_int_2d,2);

%coordinates
x1=20; x1=double(x1);
x2=uint16(dimB*0.5); x2=double(x2);
x3=dimB-10; x3=double(x3);

y1=15; y1=double(y1);
y2=uint16(dimA*0.5); y2=double(y2);
y3=dimA-15; y3=double(y3);

%registration control points
control_x_1=[x1,x2,x3]';
control_x_2=[x1,x2,x3]';
control_y_1=[y1,y2,y3]';
control_y_2=[y1,y2,y3]';

%displacements
x_mid=uint16(dimB.*0.5); x_mid=double(x_mid);
y_mid=uint16(dimA.*0.5); y_mid=double(y_mid);
del_y=y_mid-y_max;
del_x=x_mid-x_max;

%the transform
control_x_1=control_x_1-del_x;
control_y_1=control_y_1-del_y;
tform = cp2tform([control_x_2,control_y_2],[control_x_1,control_y_1],'affine');

%shifting
red_int_2d_shift=imtransform(red_int_2d,tform,'xdata',[1,size(b2,2)],'ydata',[1,size(b2,1)]);
red_cl_2d_shift=imtransform(red_cl_2d,tform,'xdata',[1,size(b2,2)],'ydata',[1,size(b2,1)]);

%rgb rendering
[gr_int_2d_rgb]=make_rgb_im(gr_int_2d,1,0.75);
[red_int_2d_rgb]=make_rgb_im(red_int_2d_shift,2,0.75);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Highlighting the clusters that%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%colocalize well%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%blob_matrix,
%blob_num

%masks
gr_mask_final=zeros(size(gr_cl_2d));
red_mask_final=zeros(size(red_cl_2d_shift));

%creating masks
for r=1:numel(blob_matrix(:,1))
    
    %look for cluster in 2d projection
    idx_gm=find(gr_cl_2d==blob_matrix(r,1));
    idx_rm=find(red_cl_2d_shift==blob_matrix(r,2));
    
    if numel(idx_gm)>0
        gr_mask_final(idx_gm)=1;
    end
    if numel(idx_rm)>0
        red_mask_final(idx_rm)=1;
    end
    
    %clear statements
    clear idx_gm; clear idx_rm;
    
end

%figure, imagesc(red_mask_final); colormap(gray); colorbar

%dimming factor
damp_fac=1;

%dimming the green image
idx_gr_dim=find(gr_mask_final==0);
[x_gr_dim,y_gr_dim]=ind2sub(size(gr_mask_final),idx_gr_dim);
gr_int_2d_rgb_dim=gr_int_2d_rgb;

gr_mask_final=double(gr_mask_final);
gr_cl_2d=double(gr_cl_2d);
thing_send_build_green=gr_cl_2d.*gr_mask_final;

for q=1:numel(x_gr_dim)
    gr_int_2d_rgb_dim(x_gr_dim(q),y_gr_dim(q),1)=gr_int_2d_rgb(x_gr_dim(q),y_gr_dim(q),1).*damp_fac;
    gr_int_2d_rgb_dim(x_gr_dim(q),y_gr_dim(q),2)=gr_int_2d_rgb(x_gr_dim(q),y_gr_dim(q),2).*damp_fac;
    gr_int_2d_rgb_dim(x_gr_dim(q),y_gr_dim(q),3)=gr_int_2d_rgb(x_gr_dim(q),y_gr_dim(q),3).*damp_fac;
end

%dimming the red image
idx_red_dim=find(red_mask_final==0);
[x_red_dim,y_red_dim]=ind2sub(size(red_mask_final),idx_red_dim);
red_int_2d_rgb_dim=red_int_2d_rgb;

red_mask_final=double(red_mask_final);
red_cl_2d_shift=double(red_cl_2d_shift);
thing_send_build_red=red_mask_final.*red_cl_2d_shift;

for d=1:numel(x_red_dim)
   red_int_2d_rgb_dim(x_red_dim(d),y_red_dim(d),1)=red_int_2d_rgb_dim(x_red_dim(d),y_red_dim(d),1).*damp_fac;
   red_int_2d_rgb_dim(x_red_dim(d),y_red_dim(d),2)=red_int_2d_rgb_dim(x_red_dim(d),y_red_dim(d),2).*damp_fac;
   red_int_2d_rgb_dim(x_red_dim(d),y_red_dim(d),3)=red_int_2d_rgb_dim(x_red_dim(d),y_red_dim(d),3).*damp_fac;
end


%figure for debugging
figure, imshow([gr_int_2d_rgb,red_int_2d_rgb,gr_int_2d_rgb+red_int_2d_rgb]); 
figure, imshow([gr_int_2d_rgb_dim,red_int_2d_rgb_dim,gr_int_2d_rgb_dim+red_int_2d_rgb_dim]);hold on;

outline_the_clusters(thing_send_build_green,1);
outline_the_clusters(thing_send_build_red,2);
john=10000












