function[node_villi_height]=make_node_of_villi_height(node1,villi_c,villi_flat)

%This is a function to create a node matrix with villi numbers

%creating a node matrix to return
node_villi_height=node1;
node_villi_height(:,4)=0;


for i=1:size(villi_flat,1)
    
    %get the height information
    the_height_tmp=villi_flat(i,1);
    the_height=the_height_tmp{1};
    max_height=max(the_height(:,5));
    
    %get the villi coordinates
    villi_coord_tmp=villi_c(i,1);
    villi_coord=villi_coord_tmp{1};
    
    for j=1:numel(villi_coord(:,1))
        dist_check=(villi_coord(j,1)-node_villi_height(:,1))+(villi_coord(j,2)-node_villi_height(:,2))+(villi_coord(j,3)-node_villi_height(:,3));
        idx_check=find(dist_check==0);
        if numel(idx_check)>0
            node_villi_height(idx_check,4)=max_height;
        end
        clear idx_check; clear dist_check;
        
    end
    
    %clear statements
    clear the_height_tmp; clear the_height;
    clear max_height; clear villi_coord_tmp; clear villi_coord;
    
end






