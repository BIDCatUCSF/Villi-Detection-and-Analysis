function[vec_ret]=look_through(test1,the_list)

%This is a function to basically look through "the_list" and find all
%elements connected to test1

%inputs
%test1 = vector - two microvilli [A,B] that I am curious about
%the_list = this is the merge matrix


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%making copy for debugging
the_list_ret=the_list;

%adding a column to include indices
the_list_ret(:,3)=[1:numel(the_list_ret(:,1))]';

%the indices of search
idx_search=0;

%counter for searching
count_search=1;
count_return=1;

%intializing parameter
nums_not_same=[];

%intializing output
vec_ret=0;

while numel(idx_search)>0
    
    %clearing the search indices
    idx_search=[];
    
    if count_search == 1
        
        %search
        idx_search1=find(the_list_ret(:,1)==test1(1));
        idx_search2=find(the_list_ret(:,2)==test1(1));
        idx_search3=find(the_list_ret(:,1)==test1(2));
        idx_search4=find(the_list_ret(:,2)==test1(2));
        idx_search_tmp=[idx_search1;idx_search2;idx_search3;idx_search4];
        
        %remove duplicate
        idx_search = unique(idx_search_tmp,'rows');
        
        %clear statements
        clear idx_search1; clear idx_search2; clear idx_search_tmp;
        clear idx_search3; clear idx_search4;
        
    elseif count_search>1 && numel(nums_not_same)>0
       
        %counter for search
        count_search2=1;
        
        for k=1:numel(nums_not_same)
            
            %search
            idx_search1=find(the_list_ret(:,1)==nums_not_same(k));
            idx_search2=find(the_list_ret(:,2)==nums_not_same(k));
            idx_search_tmp=[idx_search1;idx_search2];
            
            %combining
            if numel(idx_search_tmp)>0 && count_search2 == 1
                idx_search=idx_search_tmp;
            elseif numel(idx_search_tmp)>0 && count_search2 > 1
                idx_search_tmp_tmp=idx_search;
                clear idx_search;
                idx_search=[idx_search_tmp_tmp;idx_search_tmp];
                clear idx_search_tmp_tmp;
            end
            
            %iterate counter
            if numel(idx_search_tmp)>0 && count_search2 == 1
                count_search2=count_search2+1;
            end
            
            %clear statements
            clear idx_search1; clear idx_search2; clear idx_search_tmp;
            
        end
        
        %removing duplicate rows
        idx_search_hold=idx_search;
        clear idx_search;
        idx_search=unique(idx_search_hold,'rows');
        clear idx_search_hold;
        
    end
    
    %identify all elements that do not equal test value
    if numel(idx_search)>0 && count_search==1
       
        %piece of matrix
        thing_left=the_list_ret(idx_search,:);
        
        %filling return
        for t=1:numel(thing_left(:,1))
            vec_ret(count_return,1)=thing_left(t,3); %storing index
            count_return=count_return+1;
        end
        
        %going through
        count_it=1;
        thing_left_loop=[thing_left(:,1),thing_left(:,2)];
        for s=1:numel(thing_left_loop)
           if thing_left(s) ~= test1(1) && thing_left(s) ~= test1(2)
               nums_not_same_tmp(count_it,1)=thing_left(s);
               count_it=count_it+1;
           end
        end
        clear thing_left_loop;
        
        %removing duplicate rows
        nums_not_same=unique(nums_not_same_tmp,'rows');
        
        %removing
        the_list_ret(idx_search,:)=[];

        %clear statments
        clear thing_left; clear idx_not_same; clear nums_not_same_tmp;
        
    elseif numel(idx_search)>0 && count_search > 1
            

        %piece of matrix
        thing_left=the_list_ret(idx_search,:);
        
         %filling return
        for t=1:numel(thing_left(:,1))
            vec_ret(count_return,1)=thing_left(t,3); %storing index
            count_return=count_return+1;
        end
        
        %going through
        count_it=1;
        thing_left_loop=[thing_left(:,1),thing_left(:,2)];
        for s=1:numel(thing_left_loop)
           count_check=1;
           for u=1:numel(nums_not_same)
              if thing_left_loop(s)==nums_not_same(u)
                  count_check=count_check+1;
              end
              if count_check==1
                  nums_not_same_tmp(count_it,1)=thing_left_loop(s);
                  count_it=count_it+1;
              end
           end
        end
        clear thing_left_loop;
        
        
        %removing element from matrix
        the_list_ret(idx_search,:)=[];
        
        %clearing
        clear nums_not_same; 
        
        %removing duplicate rows
        nums_not_same=unique(nums_not_same_tmp,'rows');

    end
    
    %iterate counter
    if numel(idx_search)>0 && count_search==1
        count_search=count_search+1;
    end
    
    %clear statement
    clear test1;
    
end



































