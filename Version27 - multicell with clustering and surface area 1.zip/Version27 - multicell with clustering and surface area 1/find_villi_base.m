clear all; close all;


%This is a script written to figure out how well I can find the base of
%detected villi.
%Finding the base is the basis for how I intend to characterize geometry

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Some initializations%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%villus to look at 
num_v=5;

%path
path='G:\en project\Oct2018 Images\Microvilli Detection Tests\Smoothing 2\ROI54\Thresh 05\Final Microvilli Locs\';

%cruvature threshold
ct=-0.05;

%final villi
final_villi_tmp=load(strcat(path,'Final_villi_info.mat'));
final_villi=final_villi_tmp.the_final_villi;

%original surface
node_orig_tmp=load(strcat(path,'Nodes_curvature_for_villi.mat'));
node_orig=node_orig_tmp.n_curve1;
face_orig_tmp=load(strcat(path,'FaceMat_curvature_for_villi.mat'));
face_orig=face_orig_tmp.f_curve1;

%colormaps
[ens_curve_map,ens_curve_map_mask]=get_curvature_maps;

%thresholding
node_thresh=node_orig;
idx1=find(node_thresh(:,4)<-0.5);
if numel(idx1)>0
    node_thresh(idx1,4)=-0.5;
end

idx2=find(node_thresh(:,4)>ct);
if numel(idx2)>0
    node_thresh(idx2,4)=-0.6;
end

figure, plotmesh(node_thresh,face_orig); shading interp; title('Threshed Curvature'); caxis([-0.6,0.5]);colormap(ens_curve_map_mask);  colorbar; hold on; freezeColors; 
%plot3(final_villi(:,2),final_villi(:,1),final_villi(:,3),'g+','MarkerSize',12,'LineWidth',2.5);
for c=1:numel(final_villi(:,2))
    %if final_villi(c,4)==1
        text(final_villi(c,2),final_villi(c,1),final_villi(c,3),num2str(final_villi(c,4)),'FontSize',12,'Color',[0,1,0]);
    %end
end

john=10000


%figure
figure, plotmesh(node_thresh,face_orig); shading interp; title('Threshed Curvature'); caxis([-0.6,0.5]);colormap(ens_curve_map_mask);  colorbar; hold on; freezeColors; 
plot3(final_villi(:,2),final_villi(:,1),final_villi(:,3),'g+','MarkerSize',12,'LineWidth',2.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%This is the code to fit the base of villus%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%to a plane%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter for debugging
count_debug=1;

%cell array to hold information about villi and fits
cell_villi_base=cell(1000,3);

for p=1:10%max(final_villi(:,4)) %368 is good test case
   p
    idx1=find(final_villi(:,4)==p);
    
    if numel(idx1)>0
        
        %figure
        %figure, hold on; plotmesh(node_thresh,face_orig); shading interp; title(num2str(p)); caxis([-0.6,0.5]);colormap(ens_curve_map_mask); freezeColors;  colorbar; hold on;
        
        %counter
        count_x=1;
        
        %pre-allocating for speed
        arr_mask=zeros(numel(idx1),4);
        arr_mask=double(arr_mask);
        
        %getting nodes of villus
        arr_mask(:,1)=final_villi(idx1,2);
        arr_mask(:,2)=final_villi(idx1,1);
        arr_mask(:,3)=final_villi(idx1,3);
        arr_mask(:,4)=final_villi(idx1,6);
   
        %plotting the villi
         figure, hold on; plotmesh(node_thresh,face_orig); shading interp; title(num2str(p)); caxis([-0.6,0.5]);colormap(ens_curve_map_mask); freezeColors;  colorbar; hold on;
        plot3(arr_mask(:,1),arr_mask(:,2),arr_mask(:,3),'g+','MarkerSize',20,'LineWidth',2);
%         
        %Finding the base of villi
        if numel(idx1)>0
            
            %fitting entire set of points that 
            thing_send_tmp=final_villi(idx1,:);
            thing_send(:,2)=thing_send_tmp(:,1);
            thing_send(:,1)=thing_send_tmp(:,2);
            thing_send(:,3)=thing_send_tmp(:,3);
            %fit_base_of_villus(thing_send);
            
            %getting flat points around villus to fit. - round 1
           [villi_for_fit]=get_pts_around_villus_for_fit_initial(thing_send_tmp,node_orig,face_orig);

           
           %plotting for debugging
           plot3(villi_for_fit(:,1),villi_for_fit(:,2),villi_for_fit(:,3),'r+','MarkerSize',12,'LineWidth',5);
           
           %Fitting
           [x_plane,y_plane,z_plane,n_plane,p_plane]=fit_base_of_villus_v3(villi_for_fit,arr_mask,node_orig);
           
           %calculate height of the villus relative to plane
           [arr_mask_w_height]=get_villus_height(arr_mask,[x_plane,y_plane,z_plane],n_plane,p_plane);

           %storing information in cell array
           cell_villi_base(count_debug,1)={arr_mask_w_height};
           cell_villi_base(count_debug,2)={[x_plane,y_plane,z_plane]};
           cell_villi_base(count_debug,3)={p};
           
           %iterate debugging counter
           count_debug=count_debug+1;
           
            %clear statements
            clear thing_send; clear thing_send_tmp; clear thing_send_sort; clear thing_bot; clear curve_out;
            clear thing_bot_tmp;
            
        end
    end

    %clear statements
    clear idx1;
    
end
 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%Characterization of each villus%%%%%%%%%%%%%%%%%%%%%%
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%Figuring out the rotation necessary to put the plane on%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2d axis%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %defining rotation matrix
figure, hold on; 

%cell array to hold the flattened plane
cell_flat=cell((count_debug-1),1);

for s=1:(count_debug-1)
    s
    %grabbing a plane to fit
    mA_tmp=cell_villi_base(s,2); mA=mA_tmp{1};
    xA=mA(:,1); yA=mA(:,2); zA=mA(:,3);
    
    %get the villus
    vA_tmp=cell_villi_base(s,1); vA=vA_tmp{1};
    
    %getting the height and curvature information
    [curvature_list_now,height_list_now]=map_villus_to_plane(xA,yA,zA,vA);

    for t=1:6
        
        %pre-allocating for speed
        del_keep=zeros(360,2);
        del_keep=double(del_keep);
        
        for k=1:360
            
            %define theta
            theta=double(-180+(k)-1);
            theta=theta.*(pi/180);
            
            %define rotation matrix
            if t==1 %x axis
                rot_mat=rotationmat3D(theta,[1 0 0]);
            elseif t==2 % y axis
                rot_mat=rotationmat3D(theta,[0 1 0]);
            elseif t==3 % z axis
                rot_mat=rotationmat3D(theta,[0 0 1]);
            elseif t==4 %x z axes
                rot_mat=rotationmat3D(theta,[1 0 1]);
            elseif t==5 %x y axes
                rot_mat=rotationmat3D(theta,[1 1 0]);
            elseif t==6 %y z axes
                rot_mat=rotationmat3D(theta,[0 1 1]);
            end
            
            
            %applying rotation matrix
            for j=1:numel(xA)
                
                vec=[xA(j);yA(j);zA(j)];
                thing_plot=[rot_mat*vec]';
                coord_2d(j,:)=[thing_plot];
                
                %clear statements
                clear vec; clear thing_plot;
                
            end
            
            %seeing how close to being purely in xy plabe coordinates are
            del_keep(k,1)=theta;
            del_keep(k,2)=abs(min(coord_2d(:,3))-max(coord_2d(:,3)));
            
            
            %clear statements
            clear theta; clear rot_mat;
            clear coord_2d;
            
        end
        
        %storing extrema information
        extrema_info(t,1)=min(del_keep(:,2));
        
        %locating angles where extrema occurred
        idx_ang_x=find(del_keep(:,2)==min(del_keep(:,2)));
        
        %storing angles
        extrema_info(t,2)=del_keep(idx_ang_x(1),1);
        
        
        %clear statement
        clear del_keep; clear idx_ang_x; clear idx_ang_y; clear idx_ang_z;

    end
    
    %figuring out the rotation angle to use
    min_diff=min(extrema_info(:,1));
    idx_diff=find(extrema_info(:,1)==min_diff);
    theta_use=extrema_info(idx_diff(1),2);
    
    %figuring out which rotation matrix to use
    if idx_diff(1)==1 %x axis
        rot_mat_use=rotationmat3D(theta_use,[1 0 0]);
    elseif idx_diff(1)==2 % y axis
        rot_mat_use=rotationmat3D(theta_use,[0 1 0]);
    elseif idx_diff(1)==3 % z axis
        rot_mat_use=rotationmat3D(theta_use,[0 0 1]);
    elseif idx_diff(1)==4 %x z axes
        rot_mat_use=rotationmat3D(theta_use,[1 0 1]);
    elseif idx_diff(1)==5 %x y axes
        rot_mat_use=rotationmat3D(theta_use,[1 1 0]);
    elseif idx_diff(1)==6 %y z axes
        rot_mat_use=rotationmat3D(theta_use,[0 1 1]);
    end
    
    %applying rotation matrix
    for m=1:numel(xA)
        
        %cooridinates
        vec1=[xA(m);yA(m);zA(m)];
        thing_plot1=[rot_mat_use*vec1]';
        final_data_in_xy(m,1)=thing_plot1(1);
        final_data_in_xy(m,2)=thing_plot1(2);
        final_data_in_xy(m,3)=thing_plot1(3);
        
        %adding curvature here 
        if curvature_list_now(m)~=-1000
            final_data_in_xy(m,4)=curvature_list_now(m);
        else
            final_data_in_xy(m,4)=-1000;
        end
        
        %adding the height here
        if height_list_now(m)~=1000
            final_data_in_xy(m,5)=height_list_now(m);
        else
            final_data_in_xy(m,5)=-1000;
        end
        
        %clear statements
        clear vec1; clear thing_plot1;
        
    end
    
    %storing the flattened data
    cell_flat(s,1)={final_data_in_xy};
    
    %making a figure
    figure, hold on; 
    plot3(xA,yA,zA,'ro','MarkerSize',12,'LineWidth',2);
    plot(final_data_in_xy(:,1),final_data_in_xy(:,2),'k+');
    
 
    %clear statements
    clear xA; clear yA; clear zA;
    clear mA; clear mA_tmp;
    clear vA; clear vA_tmp;
    clear extrema_info; clear min_diff; clear idx_diff;
    clear theta_use; clear rot_mat_use; clear final_data_in_xy;
    
    
end


%saving the data
save('original_villus_info2.mat','cell_villi_base');
save('villus_info_flat_surface2.mat','cell_flat');

% load('original_villus_info.mat');
% load('villus_info_flat_surface.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%calculating parameters of villi%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure, plotmesh(node_thresh,face_orig); shading interp; title('Threshed Curvature'); caxis([-0.6,0.5]);colormap(ens_curve_map_mask);  colorbar; hold on; freezeColors; 

figure, plotmesh(node_thresh,face_orig); shading interp; title('Threshed Curvature'); caxis([-0.6,0.5]);colormap(ens_curve_map_mask);  colorbar; hold on; freezeColors; 
%plot3(final_villi(:,2),final_villi(:,1),final_villi(:,3),'g+','MarkerSize',12,'LineWidth',2.5);
for c=1:numel(final_villi(:,2))
    if final_villi(c,4)==1
        text(final_villi(c,2),final_villi(c,1),final_villi(c,3),num2str(final_villi(c,4)),'FontSize',12,'Color',[0,1,0]);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Surface area%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%creating a node matrix with villus number
[node_villi_ret]=make_node_of_villi(node_orig,final_villi);

%calculation of surface area
[surface_area_cluster,node_villi_sa]=calculate_surface_area_villi(node_villi_ret,face_orig);

%jet colormap
jet_masked=get_jet_map();

%make a figure withvilli number
figure, hold on; plotmesh(node_villi_ret,face_orig); shading interp; title('Villi Number'); colormap(jet_masked); freezeColors;  colorbar; hold on;

%make a figure with surface area
figure, hold on; plotmesh(node_villi_sa,face_orig); shading interp; title('Surface Area'); colormap(jet_masked);  freezeColors;  colorbar; hold on;
%plot3(final_villi(:,2),final_villi(:,1),final_villi(:,3),'g+','MarkerSize',12,'LineWidth',2.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Height of Villus%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get height information
[node_villi_height_ret]=make_node_of_villi_height(node_orig,cell_villi_base,cell_flat);

%scaling the height of the villus to be in microns - assuming everyone is
%using LLS system here
node_villi_height_ret(:,4)=node_villi_height_ret(:,4).*0.1;

%make a figure with height
figure, hold on; plotmesh(node_villi_height_ret,face_orig); shading interp; title('Villi Height'); colormap(jet_masked); freezeColors;  colorbar; hold on;
%plot3(final_villi(:,2),final_villi(:,1),final_villi(:,3),'g+','MarkerSize',12,'LineWidth',2.5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Base area%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[node_perimeter_ret,node_ecc_ret,node_base_area_ret]=make_node_villi_base_area_eccentricity(cell_flat,cell_villi_base,node_villi_ret);
% figure, imagesc(im_cv); colormap(gray); colorbar; title('Mask of CV');

%scaling the area of villus base to be in microns squared - assuming use of
%LLS system
node_base_area_ret(:,4)=node_base_area_ret(:,4)*0.1*0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Multi-panel figure%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

make_multi_panel_figure(node_perimeter_ret,face_orig);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%Creating matrices with parameters describing%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%villi%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%villi extrema
idx_nonzero=find(node_villi_ret(:,4)>0);
thing_min_max=node_villi_ret(idx_nonzero,4);
min_vf=min(thing_min_max);
max_vf=max(thing_min_max);

%counter
count_for_hist=1;

%going through the villi
for c=1:10
    
    %look for villi
    idx_k=find(node_villi_ret(:,4)==c);
    
    if numel(idx_k)>0
        
        %making a single matrix to store information
        villi_para_master_mat(count_for_hist,1)=c;
        villi_para_master_mat(count_for_hist,2)=node_villi_height_ret(idx_k(1),4);
        villi_para_master_mat(count_for_hist,3)=node_villi_sa(idx_k(1),4);
        villi_para_master_mat(count_for_hist,4)=node_base_area_ret(idx_k(1),4);
        villi_para_master_mat(count_for_hist,5)=(double(node_villi_height_ret(idx_k(1),4)))/(double(node_base_area_ret(idx_k(1),4)));
        

        %iterate counter
        count_for_hist=count_for_hist+1;
               
    end
    
    %clear statements
    clear idx_k;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Saving Files for use in GUI%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%for debugging only
figure, hold on; plotmesh(node_thresh,face_orig); shading interp; title('Villi Number'); colormap(jet_masked); freezeColors;  colorbar; hold on;
for k=1:numel(node_villi_ret(:,4))
   
    if node_villi_ret(k,4)>0
       plot3(node_villi_ret(k,1),node_villi_ret(k,2),node_villi_ret(k,3),'g+','LineWidth',1.5,'MarkerSize',12);
    end
    
end






