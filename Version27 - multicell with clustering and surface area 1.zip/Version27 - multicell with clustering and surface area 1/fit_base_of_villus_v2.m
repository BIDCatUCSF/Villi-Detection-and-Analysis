function[]=fit_base_of_villus_v2(XYZ_2_in,the_villus,the_nodes,a_num)

%This is the function that fits the base of the villus to a plane.
%Version 2 of this program has an optimization step to insure that the
%plane fits the base of villus accurately.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%finding center of tcell%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xcenter=mean(the_nodes(:,1));
ycenter=mean(the_nodes(:,2));
zcenter=mean(the_nodes(:,3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Examining the points associated with the villus%%%%%%%%%%%%%%%%

%locate peak
c_peak=min(the_villus(:,4));
idx_peak=find(the_villus(:,4)==c_peak);
x_peak=the_villus(idx_peak(1),1);
y_peak=the_villus(idx_peak(1),2);
z_peak=the_villus(idx_peak(1),3);

%locate 2 of the points of the villus that are flat
the_villus_as=sortrows(abs(the_villus),4);
the_villus_flat=the_villus_as(1:2,:);
the_villus_flat(:,4)=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%Fitting the flat points%%%%%%%%%%%%%%%%%%%%%%%%%%%

%the initial fitting
[X1,Y1,Z1,the_width1]=fit_base_of_villus_wrapper(XYZ_2_in);

%testing quality of fit - distance to peak
dist_peak=(((x_peak-X1).^2)+((y_peak-Y1).^2)+((z_peak-Z1).^2)).^0.5;
min_peak_dist=min(dist_peak)

%testing quality of fit - distance to flat part of villus
dist_flat1=(((the_villus_flat(1,1)-X1).^2)+((the_villus_flat(1,2)-Y1).^2)+((the_villus_flat(1,3)-Z1).^2)).^0.5;
dist_flat2=(((the_villus_flat(2,1)-X1).^2)+((the_villus_flat(2,2)-Y1).^2)+((the_villus_flat(2,3)-Z1).^2)).^0.5;
min_dist_flat1=mean(dist_flat1)
min_dist_flat2=mean(dist_flat2)

%initialize flag
flag=0;

if min_dist_flat1 > min_peak_dist || min_dist_flat2 > min_peak_dist
    
    %flag - the fit is messed up
    flag=1;
    
    a_num
    
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% %plot the plane on the surface%%%%%%%%%%%%%%%%%%%%%%%%

surf(reshape(X1,the_width1,the_width1),reshape(Y1,the_width1,the_width1),reshape(Z1,the_width1,the_width1),'facecolor','blue','facealpha',0.5);
xlabel('x');
ylabel('y');
zlabel('z');
axis equal




















































