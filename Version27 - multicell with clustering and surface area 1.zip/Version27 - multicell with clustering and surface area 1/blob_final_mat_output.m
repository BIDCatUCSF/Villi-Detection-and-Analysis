function[coloc_per_ret]=blob_final_mat_output(gc,green_clusters,red_clusters)

%inputs
%gc = colocalization map
% gc(:,1) = green cluster numbers that colocalize
% gc(:,2) = red cluster numbers that colocalize

%green_clusters = cluster information
% green_clusters(:,1) = green cluster number
% green_clusters(:,2) = x
% green_clusters(:,3) = y
% green_clusters(:,4) = z

%red_clusters = cluster information
% red_clusters(:,1) = red cluster number
% red_clusters(:,2) = x
% red_clusters(:,3) = y
% red_clusters(:,4) = z

%outputs
%This function returns the colocalization % of the blobs. A blob is a set
%of colocalizing red and green clusters. Colocalization is relative to the
%largest cluster in set. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Getting coordinates of relevant clusters%%%%%%%%%%%%%%%

%some unit conversion
green_clusters=double(green_clusters);
red_clusters=double(red_clusters);

%first green cluster number
idx_gr1=gc(1,1);
idx_mul_gr1=find(gc(:,1)==idx_gr1); 
idx_green1=gc(idx_mul_gr1,1);
 
%red clusters
idx_red1=gc(idx_mul_gr1,2);

%Get all coordinates associated with red clusters
for i=1:numel(idx_red1)
    idx_r=find(red_clusters(:,1)==idx_red1(i));
    if i==1
        red_coord1=[red_clusters(idx_r,1),red_clusters(idx_r,2),red_clusters(idx_r,3),red_clusters(idx_r,4)];
    else
        red_coord_tmp=red_coord1;
        clear red_coord1;
        red_coord1=[red_coord_tmp;[red_clusters(idx_r,1),red_clusters(idx_r,2),red_clusters(idx_r,3),red_clusters(idx_r,4)]];
        clear red_coord_tmp;
    end
    clear idx_r;
end

%get coordinates of green clusters
for j=1:numel(idx_mul_gr1)
   idx_g=find(green_clusters(:,1)==idx_green1(j)); 
   if j==1
       green_coord1=[green_clusters(idx_g,1),green_clusters(idx_g,2),green_clusters(idx_g,3),green_clusters(idx_g,4)];
   else
      green_coord_tmp=green_coord1;
      clear green_coord1;
      green_coord1=[green_coord_tmp;[green_clusters(idx_g,1),green_clusters(idx_g,2),green_clusters(idx_g,3),green_clusters(idx_g,4)]];
      clear green_coord_tmp;
   end
   clear idx_g;
end

%removing duplicate rows
green_coord=unique(green_coord1,'rows');
red_coord=unique(red_coord1,'rows');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%figure out number of pixels that overlap%%%%%%%%%%%%%%%%

%initialize number of overlapping pixels
num_overlap=0;

%some conversion
green_coord=double(green_coord);
red_coord=double(red_coord);

for k=1:numel(green_coord(:,1))
   
    %calculate distances
    dist_arr=(((green_coord(k,2)-red_coord(:,2)).^2)+((green_coord(k,3)-red_coord(:,3)).^2)+((green_coord(k,4)-red_coord(:,4)).^2)).^0.5;
    
    %find overlapping voxels
    idx_zero=find(dist_arr<0.5);
    
    if numel(idx_zero)>0
        num_overlap=num_overlap+numel(idx_zero);
    end
    
    %clear statements
    clear dist_arr; clear idx_zero;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Figuring out what condition you have%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%for colocalization calculation%%%%%%%%%%%%%%%%%%%%%%%%

%3 conditions
%1 - 1 green cluster coloc with multiple red clusters
%2 - multiple green clusters coloc with single red cluster
%3 - 1 green cluster coloc with 1 red cluster

%first green cluster number
idx_gr1=gc(1,1);

%first red cluster number
idx_red1=gc(1,2);

%checking for conditions
idx_gr_check1=find(gc(:,1)==idx_gr1); 
idx_red_check1=find(gc(:,2)==idx_red1); 

%condition #1
if numel(idx_gr_check1)>1 && numel(idx_red_check1)==1

    %total number of pixels in green cluster
    tot_num_pix=numel(green_coord(:,1));
    
%condition #2
elseif numel(idx_gr_check1)==1 && numel(idx_red_check1)>1
   
    %total number of pixels in red cluster
    tot_num_pix=numel(red_coord(:,1));
    
%condition #3
else
    
    if numel(red_coord(:,1)) >= numel(green_coord(:,1))
        tot_num_pix=numel(red_coord(:,1));
    else
        tot_num_pix=numel(green_coord(:,1));
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%colocalization percentage%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

coloc_per_ret=(num_overlap/tot_num_pix)*100;




