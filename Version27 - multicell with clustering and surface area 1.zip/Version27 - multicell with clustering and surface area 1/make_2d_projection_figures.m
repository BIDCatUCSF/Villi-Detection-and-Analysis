function[int_proj_surf]=make_2d_projection_figures(cell_A,the_nodeA)

%This is a function that makes surfaces into 2d projections that look like
%t-cells. 

%inputs
%cell_A(1,1) = 2d intensity projection
%cell_A(2,1) = 2d cluster projections
%cell_A(3,1) = 2d x coordinate projection
%cell_A(4,1) = 2d y coordinate projection
%cell_A(5,1) = 2d z coordinate projection

%the_nodeA = node matrix of intensities, curvature, ... anything

%outputs
%int_proj_surf - 2d projection based on surface (the_nodeA matrix)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%The Code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%open the cell array
int_proj_tmp=cell_A(1,1);
int_proj=int_proj_tmp{1};

cluster_proj_tmp=cell_A(2,1);
cluster_proj=cluster_proj_tmp{1};

x_proj_tmp=cell_A(3,1);
x_proj=x_proj_tmp{1};

y_proj_tmp=cell_A(4,1);
y_proj=y_proj_tmp{1};

z_proj_tmp=cell_A(5,1);
z_proj=z_proj_tmp{1};


%pre-allocate intensity projection
%based on surface
dim1=size(int_proj,1);
dim2=size(int_proj,2);
int_proj_surf=zeros(dim1,dim2);

%find all non-zero entries
idx_use=find(int_proj>0);

for i=1:numel(idx_use)
    
   %get coordinates from the original projection
   xp=x_proj(idx_use(i));
   yp=y_proj(idx_use(i));
   zp=z_proj(idx_use(i));
    
   %distance calculation
   dist_p=(((xp-the_nodeA(:,2)).^2)+((yp-the_nodeA(:,1)).^2)+((zp-the_nodeA(:,3)).^2)).^0.5;
   
   %finding minimum distance
   min_dist=min(dist_p);
   idx_min=find(dist_p==min_dist);
   
   %load the projection
   int_proj_surf(idx_use(i))=the_nodeA(idx_min(1),4);
    
    %clear statements
    clear xp; clear yp; clear zp;
    clear dist_p; clear min_dist; clear idx_min;
    
end
% 
% figure, imagesc(int_proj); colormap(gray); colorbar; title('Original Projection');
% figure, imagesc(int_proj_surf); colormap(gray); colorbar; title('Surface Projection');





















