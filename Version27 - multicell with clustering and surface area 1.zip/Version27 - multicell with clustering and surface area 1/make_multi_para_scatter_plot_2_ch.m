function[]=make_multi_para_scatter_plot_2_ch(ncurve1,ncluster1,ncluster_info1,ncurve2,ncluster2,ncluster_info2,stats_cl_1,stats_cl_2,is_it_size)

%          stats_to_return(count_jp,1)=r; %cluster number
%         stats_to_return(count_jp,2)=curr_size_arr(1); %cluster size
%         stats_to_return(count_jp,3)=curr_int_arr(1);  %cluster intensity
%         stats_to_return(count_jp,4)=mean(curr_curv); %mean curvature
%         stats_to_return(count_jp,5)=std(curr_curv); %std dev of curvature

%cluster extrema
min_cl_1=min(stats_cl_1(:,1));
max_cl_1=max(stats_cl_1(:,1));

min_cl_2=min(stats_cl_2(:,1));
max_cl_2=max(stats_cl_2(:,1));

%figures - set 1
make_scatter_plot(min_cl_1,max_cl_1,ncurve1,ncluster1,ncluster_info1,is_it_size,stats_cl_1,'Ch1')
make_scatter_plot(min_cl_2,max_cl_2,ncurve2,ncluster2,ncluster_info2,is_it_size,stats_cl_2,'Ch2')

%figures set 2
make_scatter_plot_mixed(min_cl_2,max_cl_2,ncurve1,ncluster2,ncluster_info2,is_it_size,0);
make_scatter_plot_mixed(min_cl_1,max_cl_1,ncurve2,ncluster1,ncluster_info1,is_it_size,1);










