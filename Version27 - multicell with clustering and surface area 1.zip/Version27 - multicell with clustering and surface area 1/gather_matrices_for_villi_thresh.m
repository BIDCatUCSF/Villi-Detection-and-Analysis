function[Node_base_area1,Node_villi_height1,Node_villi_SA1,node_curve1,node_int1,Face_mat_villi1,int_stack,ns,ne,min_curve,max_curve,cluster_stack_ret]=gather_matrices_for_villi_thresh(path_geo1,ch_in)

%This is a function that returns all the matrices and images
%stacks necessary to compare villi geomety and colocalized clusters


%inputs
%path_geo1 = \...\g0\Final Microvilli Locs\Villi Geometry\
%ch_in = channel 1 or 2 (integer)

%outputs - node matrices
% Node_base_area1
% Node_villi_height1
% Node_villi_SA1
% node_curve1
% node_int1
% 
% Face_mat_villi1
% 
% int_stack
% ns
% ne



%loading node matrices - geometry
Face_mat_villi1_tmp=load(strcat(path_geo1,'Face_Matrix_Villi_Geometry.mat'));
Node_base_area1_tmp=load(strcat(path_geo1,'Node_of_base_area.mat'));
Node_villi_height1_tmp=load(strcat(path_geo1,'Node_of_villi_height.mat'));
Node_villi_SA1_tmp=load(strcat(path_geo1,'Node_of_villi_SA.mat'));
Face_mat_villi1=Face_mat_villi1_tmp.face_orig;
Node_base_area1=Node_base_area1_tmp.node_base_area_ret;
Node_villi_height1=Node_villi_height1_tmp.node_villi_height_ret;
Node_villi_SA1=Node_villi_SA1_tmp.node_villi_sa;

%loading node matrices - curvature
idx_dashes1=find(path_geo1=='\');
path_c1=path_geo1(1:(idx_dashes1(numel(idx_dashes1)-1)));
node_curve1_tmp=load(strcat(path_c1,'Nodes_curvature_for_villi.mat'));
node_curve1=node_curve1_tmp.n_curve1;

%loading node matrices - intensity
node_int1_tmp=load(strcat(path_c1,'Nodes_intensity_for_villi.mat'));
node_int1=node_int1_tmp.i_curve1;

%get the curvature threshold
if ch_in==1
    the_file_thresh=strcat(path_c1,'Ch1_villi_thresh_info.txt');
    fileID=fopen(the_file_thresh,'r');
else
   the_file_thresh=strcat(path_c1,'Ch2_villi_thresh_info.txt');
    fileID=fopen(the_file_thresh,'r'); 
end    

%format - string
formatSpec='%s';

%getting the initial cell array
A=textscan(fileID,formatSpec);

%breaking apart cell array
B=A{1};

%element 6 = minimum threshold
min_curve_thresh_tmp=B(6);
min_curve=str2num(min_curve_thresh_tmp{1});

%element 12 = maximum threshold
max_curve_thresh_tmp=B(12);
max_curve=str2num(max_curve_thresh_tmp{1});

%get the stack of intensity images - path
idx_dashes1A=find(path_c1=='\');
path_i1_tmp=path_c1(1:(idx_dashes1A((numel(idx_dashes1A)-1))));
path_i1=strcat(path_i1_tmp,'ErodedThreshImsTmp\');
a1=dir([path_i1 '/*.tif']);
num_images1=numel(a1);

%get the stack of intensity images - path and image numbers
files1 = dir(fullfile(path_i1, '*.tif'));
im1_test=files1.name;
im1_period=find(im1_test=='.');
the_num1_tmp=im1_test(im1_period(1)-2:im1_period(1)-1);
the_num1=str2num(the_num1_tmp);
if numel(the_num1)==0
    clear the_num1_tmp;
    clear the_num1;
    the_num1_tmp=im1_test(im1_period(1)-1);
    the_num1=str2num(the_num1_tmp);
end
ns=the_num1;
ne=the_num1+num_images1-1;

%get the stack of intensity images - the stack
count_stack=1;
for b=ns:ne
    
    %read in an image
    im1=imread(strcat(path_i1,'ErodedThresh',num2str(b),'.tif'));
    
    %pre-allocate the stack
    if b==ns
        dim1=size(im1,1);
        dim2=size(im1,2);
        int_stack=zeros(dim1,dim2,num_images1);
    end
    
    %loading stack
    int_stack(:,:,count_stack)=im1;
    
    %iterate counter
    count_stack=count_stack+1;
    
    %clear statements
    clear im1;
    
end

%get the stack of clusters
path_cs1=strcat(path_i1_tmp,'WholeImageStackClustering\Intensity Stack\');

%counter cluster stack
count_cs_stack=1;

for c=ns:ne
    
    %read in image
    im1c=imread(strcat(path_cs1,'Im',num2str(c),'.tif'));
    
    if c==ns
        dim1c=size(im1c,1);
        dim2c=size(im1c,2);
        cluster_stack_ret=zeros(dim1c,dim2c,num_images1);
    end
    
    %load stack
    cluster_stack_ret(:,:,count_cs_stack)=im1c;
    
    %iterate counter
    count_cs_stack=count_cs_stack+1;
    
    %clear statmeent
    clear im1c;

end







