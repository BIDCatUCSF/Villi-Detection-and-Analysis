function[curve_ret]=peak_detection_ring_1(nodeK,faceK,the_point)

%This is a function that finds the points in the surface mesh that
%immediately surround the point of interest (the_point)

%locate the neighbors
idx1k=find(faceK(:,1)==the_point);
idx2k=find(faceK(:,2)==the_point);
idx3k=find(faceK(:,3)==the_point);

%counter for return
count_ret=1;

%initializing output
curve_ret=0;

if numel(idx1k)>0 || numel(idx2k)>0 || numel(idx3k)>0
    
    %put all the indices together
   all_k=[faceK(idx1k,1);faceK(idx1k,2);faceK(idx1k,3);faceK(idx2k,1);faceK(idx2k,2);faceK(idx2k,3);faceK(idx3k,1);faceK(idx3k,2);faceK(idx3k,3)];
   
   %put together return 
   for r=1:numel(all_k)
       if nodeK(all_k(r),1) ~= nodeK(the_point,1) && nodeK(all_k(r),2) ~= nodeK(the_point,2) && nodeK(all_k(r),3) ~= nodeK(the_point,3)
           curve_ret(count_ret,1)= nodeK(all_k(r),1);
           curve_ret(count_ret,2)= nodeK(all_k(r),2);
           curve_ret(count_ret,3)= nodeK(all_k(r),3);
           curve_ret(count_ret,4)= nodeK(all_k(r),4);
           curve_ret(count_ret,5)= all_k(r);
            
           %iterate counter
           count_ret=count_ret+1;
%            plot3(nodeK(all_k(r),1),nodeK(all_k(r),2),nodeK(all_k(r),3),'k+','MarkerSize',12,'LineWidth',3);
       end
   end

end

















