clear all; close all;

%some tests

%some definitions
path_cluster_red='H:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI54\ROI54\Registered\r0\WholeImageStackClustering\Intensity Stack\Im';
path_cluster_green='H:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI54\ROI54\Registered\g0\WholeImageStackClustering\Intensity Stack\Im';

idxDg=find(path_cluster_green=='\');
idxDr=find(path_cluster_red=='\');

path_Bg=path_cluster_green(1:idxDg(numel(idxDg)-2));
path_Br=path_cluster_red(1:idxDr(numel(idxDr)-2));

path_Bg_e=strcat(path_Bg,'ErodedThreshIms\ErodedThresh');
path_Br_e=strcat(path_Br,'ErodedThreshIms\ErodedThresh');

path_Bg2=path_cluster_green(1:idxDg(numel(idxDg)-3));

%lots of colocalization
gr_path_lots=strcat(path_Bg2,'GreenLots\Im');
red_path_lots=strcat(path_Bg2,'RedLots\Im');

%mid range colocalization
gr_path_mid=strcat(path_Bg2,'GreenMid\Im');
red_path_mid=strcat(path_Bg2,'RedMid\Im');

%not that much colocalization
gr_path_little=strcat(path_Bg2,'GreenLittle\Im');
red_path_little=strcat(path_Bg2,'RedLittle\Im');
















