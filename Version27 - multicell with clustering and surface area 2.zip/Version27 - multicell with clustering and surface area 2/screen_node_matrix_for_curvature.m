function[ret_node,idx_mask]=screen_node_matrix_for_curvature(input_node,curvey_node,curvey_stats,min_t,max_t)

%making the return node
ret_node=input_node;
ret_node(:,4)=-0.60; %This is my flag for parts of the surface that were missed by the screening.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%get all of the cluster numbers%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_good=1;

for i=1:numel(curvey_stats(:,1))

    if curvey_stats(i,4)>=min_t && curvey_stats(i,4)<=max_t
        cluster_good(count_good,1)=curvey_stats(i,1);
        count_good=count_good+1;
    end

end

%it found some values in acceptable range
if count_good>1
   
    for j=1:numel(cluster_good)

        %locate the good spots in node matrix
        good_idx=find(input_node(:,4)==cluster_good(j,1));

        if j==1
            idx_mask=good_idx;
        else
            idx_mask_tmp=idx_mask;
            clear idx_mask;
            idx_mask=[idx_mask_tmp;good_idx];
            clear idx_mask_tmp;
        end

        %clear statements
        clear good_idx;

    end

    %make the return matrix
    ret_node(idx_mask,4)=curvey_node(idx_mask,4);


else

    idx_mask=[];

end


























