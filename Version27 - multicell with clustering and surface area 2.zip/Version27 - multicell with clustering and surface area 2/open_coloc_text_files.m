function[coloc_final_mat]=open_coloc_text_files(the_file)

%inputs
%the_file = path and file for one of john's colocalization files

%outputs 
%coloc_final_mat(:,1) = cluster number of primary channel being analyzed
%coloc_final_mat(:,2) = colocalization % (based on voxel)
%coloc_final_mat(:,3) = cluster number of channel which primary channel
%                       colocalizes with
%coloc_final_mat(:,4) = Area of Green Cluster (pixel)
%coloc_final_mat(:,5) = Area of Red Cluster (pixel)

%reading in the file
fileID=fopen(the_file,'r');

%format - string
formatSpec='%s';

%getting the initial cell array
A=textscan(fileID,formatSpec);

%breaking apart cell array
B=A{1};

%counters
count=1;
count_green_num=1;
count_coloc_perc=1;
count_red_num=1;
count_green_area=1;
count_red_area=1;

for i=26:numel(B)
    
    thing_tmp=B{i};
    c_tmp=str2num(thing_tmp);
    
    if count==1
        green_num_arr(count_green_num,1)=c_tmp;
        count_green_num=count_green_num+1;
    elseif count==2
        coloc_perc_arr(count_coloc_perc,1)=c_tmp;
        count_coloc_perc=count_coloc_perc+1;
    elseif count==5
        red_num_arr(count_red_num,1)=c_tmp;
        count_red_num=count_red_num+1;
    elseif count==3
        green_area_arr(count_green_area,1)=c_tmp;
        count_green_area=count_green_area+1;
    elseif count==6
        red_area_area(count_red_area,1)=c_tmp;
        count_red_area=count_red_area+1;
    end
    
    %iterate counter
    count=count+1;
    
    %reset counter
    if count==8
        count=1;
    end
    
    %clear statements 
    clear c_tmp; clear thing_tmp;
    
end

%putting matrix together
coloc_final_mat=[green_num_arr,coloc_perc_arr,red_num_arr,green_area_arr,red_area_area];

 