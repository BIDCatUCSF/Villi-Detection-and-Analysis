function[]=surface_peak_finder(the_node,dim_in)

%inputs 
%the_node(:,1)=x coordinates of mesh
%the_node(:,2)=y coordinates of mesh
%the_node(:,3)=z coordinates of mesh
%the node(:,4)=curvature (parameters based on user selection)
%dim_in = xy size of image frame [x y]

%extrema of z
min_z=min(the_node(:,3)); min_z=uint16(min_z);
max_z=max(the_node(:,3)); max_z=uint16(max_z);

%sorting the node according to z
sorted_node=sort(the_node,3);

%going through each z slice
for p=10:10%min_z:max_z
   
    if p>0
        
        %search values
        search_high=p+0.5;
        search_low=p-0.5;
        
        %searching - high
        idx_high_tmp=find(sorted_node(:,3)<=search_high);
        if numel(idx_high_tmp)>0
            idx_high=idx_high_tmp(numel(idx_high_tmp));
        else
            idx_high=numel(the_node(:,3));
        end
        
        %searching - low
        idx_low_tmp=find(sorted_node(:,3)>=search_low);
        if numel(idx_low_tmp)>0
            idx_low=idx_low_tmp(1);
        else
            idx_low=1;
        end
        
        %pulling out the xyz coordinates for this slice (low->high)
        x_now=sorted_node(idx_low:idx_high,1);
        y_now=sorted_node(idx_low:idx_high,2);
        z_now=sorted_node(idx_low:idx_high,3);
        c_now=sorted_node(idx_low:idx_high,4);
        
        %making a mask
        the_mask=zeros(dim_in(1),dim_in(2)); the_mask=double(the_mask);
        idx_mask=sub2ind(dim_in,uint16(y_now),uint16(x_now));
        the_mask(idx_mask)=1;
        the_mask_filled=imfill(the_mask,'holes');
    
        %ok, let us try to find the boundary
        bound_tmp=bwboundaries(the_mask_filled);
        b_size_arr=zeros(size(bound_tmp,1),2);
        
        for t=1:size(bound_tmp,1)
            b_size_arr(t,1)=t;
            b_size_arr(t,2)=numel(bound_tmp{t});
        end
        
   
        sort_b_size=sortrows(b_size_arr,2)
        big_bound=sort_b_size(numel(sort_b_size(:,1)),1)
        bound_plot=bound_tmp{big_bound}
        
        figure, imagesc(the_mask); colormap(gray); colorbar; hold on;
        plot(bound_plot(:,2),bound_plot(:,1),'ro','LineWidth',1.5);
        
        figure, imagesc(the_mask_filled); colormap(gray); colorbar; title('filling test');
        
    end
    
    
end



































