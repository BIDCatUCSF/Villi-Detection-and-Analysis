function[s1_ret,s2_ret,s3_ret,s4_ret]=screen_2d_projections_by_para(s1,s2,s3,s4,p_min,p_max,is_curvature)

%This is a function written to screen 2d projections (s1,s2,s3,s4), by
%parameter minimum (p_min) and parameter maximum(p_max);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%declaring return matrices%%%%%%%%%%%%%%%%%%%%%%%%%%
s1_ret=s1;
s2_ret=s2;
s3_ret=s3;
s4_ret=s4;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%getting non-zero entries%%%%%%%%%%%%%%%%%%%%%%%%%

%2d - 1
idxA=find(s1>0);

%2d - 2
idxB=find(s2>0);

%2d - 3
idxC=find(s3>0);

%2d - 4
idxD=find(s4>0);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%screening%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(idxA)>0
   
   all_A=s1(idxA);
   idx_min_A=find(all_A<=p_min);
   idx_max_A=find(all_A>=p_max);
   
   if numel(idx_min_A)>0
       if is_curvature==0
           s1_ret(idxA(idx_min_A))=0;
       else
           s1_ret(idxA(idx_min_A))=-0.6;
       end
   end
   
   if numel(idx_max_A)>0
       if is_curvature==0
           s1_ret(idxA(idx_max_A))=0;
       else
           s1_ret(idxA(idx_max_A))=-0.6;
       end
   end
   
end


if numel(idxB)>0
   
   all_B=s2(idxB);
   idx_min_B=find(all_B<=p_min);
   idx_max_B=find(all_B>=p_max);
   
   if numel(idx_min_B)>0
       if is_curvature==0
           s2_ret(idxB(idx_min_B))=0;
       else
           s2_ret(idxB(idx_min_B))=-0.6;
       end
   end
   
   if numel(idx_max_B)>0
       if is_curvature==0
           s2_ret(idxB(idx_max_B))=0;
       else
           s2_ret(idxB(idx_max_B))=-0.6;
       end
   end
   
end




if numel(idxC)>0
   
   all_C=s3(idxC);
   idx_min_C=find(all_C<=p_min);
   idx_max_C=find(all_C>=p_max);
   
   if numel(idx_min_C)>0
       if is_curvature==0
           s3_ret(idxC(idx_min_C))=0;
       else
           s3_ret(idxC(idx_min_C))=-0.6;
       end
   end
   
   if numel(idx_max_C)>0
       if is_curvature==0
           s3_ret(idxC(idx_max_C))=0;
       else
           s3_ret(idxC(idx_max_C))=-0.6;
       end
   end
   
end




if numel(idxD)>0
   
   all_D=s4(idxD);
   idx_min_D=find(all_D<=p_min);
   idx_max_D=find(all_D>=p_max);
   
   if numel(idx_min_D)>0
       if is_curvature==0
           s4_ret(idxD(idx_min_D))=0;
       else
           s4_ret(idxD(idx_min_D))=-0.6;
       end
   end
   
   if numel(idx_max_D)>0
       if is_curvature==0
           s4_ret(idxD(idx_max_D))=0;
       else
           s4_ret(idxD(idx_max_D))=-0.6;
       end
   end
   
end



