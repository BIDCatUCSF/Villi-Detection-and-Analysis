function[]=outline_the_clusters(in_im,color_flag)

%inputs
%in_im - 2d hemispheric projection image containing cluster numbers

%size of image
d1=size(in_im,1);
d2=size(in_im,2);

%cluster exrrema
min_c=2;
max_c=max(in_im(1:(d1*d2)));

%counter for the colors 
count_color=1;

for t=min_c:max_c
    
   %blank image for boundary estimation
   bw_im=zeros(size(in_im));
    
   %look for a cluster
   idx_f=find(in_im==t);
   
   %there is cluster
   if numel(idx_f)>0
       
       %masking
       bw_im(idx_f)=1;
       
       %boundary calculation
       bound_tmp=bwboundaries(bw_im);
       
       %plotting boundaries
       for q=1:size(bound_tmp,1)
           if q==1
              bound_plot=bound_tmp{q};
           else
               bound_plot_tmp=bound_plot;
               clear bound_plot;
               bound_plot=[bound_plot_tmp;bound_tmp{q}];
               clear bound_plot_tmp;
           end
       end
       
       if color_flag ==1
           if count_color==1
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           elseif count_color==2
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           elseif count_color==3
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           elseif count_color==4
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           elseif count_color==5
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           elseif count_color==6
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           elseif count_color==7
               plot(bound_plot(:,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2),bound_plot(:,1),'g+','MarkerSize',2,'LineWidth',1);
           end
           
       else
           if count_color==1
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           elseif count_color==2
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           elseif count_color==3
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           elseif count_color==4
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           elseif count_color==5
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           elseif count_color==6
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           elseif count_color==7
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'s','LineWidth',2,'MarkerSize',2,'Color',[0.65,0.65,0.65]);
               plot(bound_plot(:,2)+size(in_im,2),bound_plot(:,1),'r+','MarkerSize',2,'LineWidth',1);
           end
       end
       
       %iterate counter
       count_color=count_color+1;
       
       if count_color==8
           count_color=1;
       end

       %clear statements
       clear bound_tmp; clear bound_plot;
       
   end
    
    %clear statement
    clear bw_im; clear idx_f;
    
    
end



























