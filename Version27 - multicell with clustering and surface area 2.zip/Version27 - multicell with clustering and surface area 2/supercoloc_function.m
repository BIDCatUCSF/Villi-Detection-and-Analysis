function[red_clusters_ret]=supercoloc_function(g_num,r_num,path_g,path_r,ns,ne,min_coverage,min_main_coverage,max_main_coverage)

%This is a function written to find what I call super-colocalizers

%Inputs
% g_num - green cluster numbers that might be part of blob
% r_num - red cluster numbers that might be part of a blob
% path_g - path to green cluster images with image name prefix
% path_r - path to red cluster images with image name prefix
% ns - starting image index
% ne - ending image index
% min_coverage - minimum amount that two clusters must overlap to be in set
%                (usually 30%)
% min_main_coverage - minimum total overlap of large cluster to be accepted
% max_main_coverage - maximum total overlap of large cluster to be accepted


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%Get the coordinates of the green cluster%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_green=1;

for b=ns:ne
    ns
    ne
   
    %read in an image
    gr_c=imread(strcat(path_g,num2str(b),'.tif'));
    
    %look for the cluster
    idx_look=find(gr_c==g_num);
    
    %store coordinates
    if numel(idx_look)>0
        
        %convert to coordinates
        [yg,xg]=ind2sub(size(gr_c),idx_look);
        zg=linspace(b,b,numel(xg))';
        
        if count_green==1
            xg_all=xg;
            yg_all=yg;
            zg_all=zg;
        else
            xg_all_tmp=xg_all; 
            clear xg_all;
            xg_all=[xg_all_tmp;xg];
            clear xg_all_tmp;
            
            yg_all_tmp=yg_all;
            clear yg_all;
            yg_all=[yg_all_tmp;yg];
            clear yg_all_tmp;
            
            zg_all_tmp=zg_all;
            clear zg_all;
            zg_all=[zg_all_tmp;zg];
            clear zg_all_tmp;
            
        end
        
        %iterate counter
        count_green=count_green+1;
        
        %clear statements
        clear xg; clear yg; clear zg;
        
    end
    
    %clear statements
    clear gr_c; clear idx_look;
    
end

%total number of voxels in green clusters
tot_num_pix_gr_cl=numel(xg_all);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%Going through the red cluster%%%%%%%%%%%%%%%%%%%%%%%%%

%NB -> r_num may be a vector

for f=1:numel(r_num)
    
    %counter
    count_r=1;

    for k=ns:ne
        
        %read in an image
        red_c=imread(strcat(path_r,num2str(k),'.tif'));
        
        %look for the red cluster
        idx_r=find(red_c==r_num(f));
        
        %storing the coordinates
        if numel(idx_r)>0
           
            %convert to coordinates
            [yr,xr]=ind2sub(size(red_c),idx_r);
            zr=linspace(k,k,numel(xr))';
            
            if count_r==1
                xr_all=xr;
                yr_all=yr;
                zr_all=zr;
            else
                xr_all_tmp=xr_all;
                clear xr_all;
                xr_all=[xr_all_tmp;xr];
                clear xr_all_tmp;
                
                yr_all_tmp=yr_all;
                clear yr_all;
                yr_all=[yr_all_tmp;yr];
                clear yr_all_tmp;
                
                zr_all_tmp=zr_all;
                clear zr_all;
                zr_all=[zr_all_tmp;zr];
                clear zr_all_tmp;
                
            end
            %iterate counter
            count_r=count_r+1;
        end
        
        %clear statements
        clear red_c; clear idx_r;
        
    end
    
    %finding the number of overlapping pixels
    
    %counter 
    counter_overlap=1;
    
    for p=1:numel(xr_all)
       dist_arr=(((xr_all(p)-xg_all).^2)+((yr_all(p)-yg_all).^2)+((zr_all(p)-zg_all).^2)).^0.5;
       idx_over=find(dist_arr==0);
       
       if numel(idx_over)>0
           if counter_overlap==1
               num_overlap=numel(idx_over);
           else
               num_overlap_tmp=num_overlap;
               clear num_overlap;
               num_overlap=num_overlap_tmp+numel(idx_over);
               clear num_overlap_tmp;
           end
           counter_overlap=counter_overlap+1;
       end
       
       clear dist_arr; clear idx_over;
    end

    %matrix about red clusters
    red_overlap_mat(f,1)=r_num(f);
    if counter_overlap>1
        red_overlap_mat(f,2)=num_overlap;
    else
        red_overlap_mat(f,2)=0;
    end
    red_overlap_mat(f,3)=numel(xr_all);
    red_overlap_mat(f,4)=(red_overlap_mat(f,2)/numel(xr_all))*100;
    
    %clear statments
    clear num_overlap; clear xr_all; clear yr_all; clear zr_all;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%deciding if we a super-colocalizer%%%%%%%%%%%%%%%%%%%%

%legend
%tot_num_pix_gr_cl = total number of pixels in green cluster
%red_overlap_mat(:,1) = red cluster #
%red_overlap_mat(:,2) = number of overlapping pixels
%red_overlap_mat(:,3) = number of pixels in red cluster
%red_overlap_mat(:,4) = %of overlapping pixels in red cluster/total #
%pixels in red cluster

%look for red clusters where at least half of their pixels overlap
idx_keep=find(red_overlap_mat(:,4)>=min_coverage);

%count how many pixels overlap with green cluster
if numel(idx_keep)>0
    for q=1:numel(idx_keep)
       if q==1
           tot_overlap_gr=red_overlap_mat(idx_keep(q),2);
       else
            tot_overlap_gr=tot_overlap_gr+red_overlap_mat(idx_keep(q),2);
       end
    end
else
    tot_overlap_gr=0;
end

%percentage of pixels that overlap (relative to total number of green
%pixels
super_per=(tot_overlap_gr/tot_num_pix_gr_cl)*100;

if super_per>=min_main_coverage && super_per <= max_main_coverage
    red_clusters_ret(:,1)=red_overlap_mat(idx_keep,1);
    red_clusters_ret(:,2)=linspace(super_per,super_per,numel(idx_keep))';
else
    red_clusters_ret=0;
end
























































