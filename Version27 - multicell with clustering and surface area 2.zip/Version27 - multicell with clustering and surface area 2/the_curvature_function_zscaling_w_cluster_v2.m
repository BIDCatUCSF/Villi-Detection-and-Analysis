function[node_curve,face_curve,global_avg,stats_to_return,node_cluster,node_cluster_size,node_cluster_intensity,node_intensity,num_start,num_end]=the_curvature_function_zscaling_w_cluster_v2(path1,file1,smooth_fac,which_kind,scale_fac,cluster_info,cluster_size,cluster_intensity,color_map_to_use,a_label)


%updates
%John E. added additional cluster inputs

%parsing out the filename
idx_per=find(file1=='.');
numb_try=file1(idx_per(1)-2:idx_per(1)-1);
num_start=str2num(numb_try);

%if the initial value is less than 1
if numel(num_start)==0
   
    %clear statements
    clear num_start; clear numb_try;
    
    %new value
    numb_try=file1(idx_per(1)-1);
    num_start=str2num(numb_try);
    
end


%figuring out how many files there are
a=dir([path1,'*.mat']);
num_ims=numel(a);

%ending index
num_end=num_start+num_ims-1;

%getting the path to the intensity images masked by the eroded boundary
idx_dash=find(path1=='\');
path_stem_tmp=path1(1:idx_dash(numel(idx_dash)-1));
path_raw=strcat(path_stem_tmp,'ErodedBoundaryImages\MaskBoundErode');

%getting the path to the cluster images
path_clust=strcat(path_stem_tmp,'WholeImageStackClustering\Intensity Stack\Im');

%image just to get dimensions
im1=imread(strcat(path_raw,num2str(num_start),'.tif'));

%scaling the z coordinate of the clustering input to match output of
%surface rendering
cluster_info_tmp=cluster_info;
clear cluster_info;
cluster_info(:,1)=cluster_info_tmp(:,1);
cluster_info(:,2)=cluster_info_tmp(:,3);
cluster_info(:,3)=cluster_info_tmp(:,2);
cluster_info(:,4)=cluster_info_tmp(:,4);
clear cluster_info_tmp;
cluster_info(:,4)=cluster_info(:,4)-num_start+1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Making the Image Stack from which%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%the surface will be rendered%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count=1;

dim1=size(im1,1);
dim2=size(im1,2);
volimage=zeros(dim1,dim2,(num_end-num_start+1));
volimage=uint16(volimage);

for i=num_start:num_end

    %reading in a boundary
    bound_tmp=load(strcat(path1,'\Bound',num2str(i),'.mat'));
    bound=bound_tmp.boundary_out;
    
    %binary image
    bin_im=poly2mask(bound(:,1),bound(:,2),dim1,dim2);

    %storing
    volimage(:,:,count)=bin_im;
      
    %new section to read in the raw images
    im_raw=imread(strcat(path_raw,num2str(i),'.tif'));
    idx_raw=find(im_raw>0);
    [y_raw,x_raw]=ind2sub(size(im_raw),idx_raw);

    %reading in the cluster image
    im_cl=imread(strcat(path_clust,num2str(i),'.tif'));
    
    %storing image data
    if count==1
        all_raw(:,1)=x_raw;
        all_raw(:,2)=y_raw;
        all_raw(:,3)=linspace(count,count,numel(x_raw))';
        all_raw(:,4)=im_raw(idx_raw);
        all_raw(:,5)=im_cl(idx_raw);
    else
        all_raw_tmp=all_raw;
        clear all_raw;
        all_raw=[all_raw_tmp;[x_raw,y_raw,linspace(count,count,numel(x_raw))',im_raw(idx_raw),im_cl(idx_raw)]];
        clear all_raw_tmp;
    end
    
    
    %iterate counter
    count=count+1;
    
    %clear statements
    clear im_raw; clear idx_raw; clear x_raw; clear y_raw; 
    clear bound_tmp; clear bound;
    clear bin_im; clear idx_binary;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% create and visualize the resulting mesh%%%%%%%%%%%%%%%%%%%%%

%code I borrowed - Initial Mesh
volimage=double(volimage);
size(volimage)
[node,elem,face]=v2m(volimage,0.8,smooth_fac,10000);

%Making the xy the same as Imaris
% x_j_tmp=node(:,2);
% y_j_tmp=node(:,1);
% node(:,1)=x_j_tmp;
% node(:,2)=y_j_tmp;

%storing
node_cluster=node;
node_cluster(:,4)=zeros(numel(node_cluster(:,3)),1);
node_cluster=double(node_cluster);
node_cluster_size=node_cluster;
node_cluster_intensity=node_cluster;

%node for calculation
node_calc=node;
node_calc(:,3)=node(:,3).*scale_fac;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%Calculate the Curvature%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%and display as 3D surface%%%%%%%%%%%%%%%%%%%%%%%%%%%


%calculating curvature
options.symmetrize = 0;
options.normalize = 1;
options.curvature_smoothing = 0
options.verb = 0;
[Umin,Umax,Cmin,Cmax,Cmean,Cgauss,Normal] = compute_curvature(node_calc,face,options);

%current curvature metrix
if which_kind==1
    curr_c=Cmean;
elseif which_kind==2
    curr_c=Cgauss;
elseif which_kind==3
    curr_c=Cmax;
end

%making colored 3d plot
node(:,4)=curr_c;

%adding global average
global_avg=curr_c;

%plotmesh(node,face); colormap(hot); colorbar; shading interp; title('Curvature');

%storing the information for the curvature surface
node_curve=node;
face_curve=face;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Some calculations about clustering%%%%%%%%%%%%%%%%%%%%%%%

%making some initialization
%z is not scaled yet!!!
face_cluster=face;
%node_cluster
%node_cluster_size
%node_cluster_intensity

%going through the raw cluster matrix
for h=1:numel(cluster_info(:,1))
   
    %get cluster number and coordinates
    ce=cluster_info(h,1);
    xe=cluster_info(h,2); xe=double(xe);
    ye=cluster_info(h,3); ye=double(ye);
    ze=cluster_info(h,4); ze=double(ze);

    %find all node points in this cluster
    dist_tay=(((node_cluster(:,1)-xe).^2)+((node_cluster(:,2)-ye).^2)+((node_cluster(:,3)-ze).^2)).^0.5;
    %dist_tay=(((node_cluster(:,2)-xe).^2)+((node_cluster(:,1)-ye).^2)+((node_cluster(:,3)-ze).^2)).^0.5;
    dist_tay=abs(dist_tay);
    min_dist_tay=min(dist_tay);
    if min_dist_tay < 1.8
        idx_tay=find(dist_tay==min_dist_tay);
    else
        idx_tay=[];
    end

    
    if numel(idx_tay)>0
        
        %get the size
        idx_size=find(cluster_size(:,1)==ce);
        idx_intens=find(cluster_intensity(:,1)==ce);
        
        %adding to node
        node_cluster(idx_tay,4)=ce;
        node_cluster_size(idx_tay,4)=cluster_size(idx_size(1),2);
        node_cluster_intensity(idx_tay,4)=cluster_intensity(idx_intens(1),2);
        
        %clear statements
        clear idx_size; clear idx_intens; 
        
    end
    
    %clear statements
    clear ce; clear xe; clear ye; clear ze;
    clear idx_tay; clear dist_tay; clear min_dist_tay;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%making a mesh plot of the intensities%%%%%%%%%%%%%%%%%%%%%

%array of intensities for colored plot
arr_int_plot=zeros(numel(node(:,1)),1);
arr_int_plot=double(arr_int_plot);

%making a double
all_raw=double(all_raw);

for k=1:numel(node(:,1))
   
    %calculating distance
    %dist_arr=(((node(k,2)-all_raw(:,1)).^2)+((node(k,1)-all_raw(:,2)).^2)+((node(k,3)-all_raw(:,3)).^2)).^0.5;
    dist_arr=(((node(k,1)-all_raw(:,2)).^2)+((node(k,2)-all_raw(:,1)).^2)+((node(k,3)-all_raw(:,3)).^2)).^0.5;
    dist_arr=abs(dist_arr);

    %finding all intensity values on the mesh
    idx_too_close=find(dist_arr<1.8);
    
    if numel(idx_too_close)>0
        arr_int_plot(k,1)=mean(all_raw(idx_too_close,4));
    end
    
    %clear statements
    clear dist_arr; clear idx_too_close; 
    
    
end

%storing the information about the surface describing the intensities
node_intensity=node;
face_intensity=face;

%making colored 3d plot
node_intensity(:,4)=arr_int_plot;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%debugging manually changing curvature to check outputs%%%%%%%%%%%%%%%

% %limits
% x_lim=[100,130];
% y_lim=[93,130];
% z_lim=[20,80];
% 
% for k=1:numel(node_curve(:,1))
% 
%     if node_curve(k,1)>=x_lim(1) && node_curve(k,1)<=x_lim(2) && node_curve(k,2)>=y_lim(1) && node_curve(k,2)<=y_lim(2) && node_curve(k,3)>=z_lim(1) && node_curve(k,3)<=z_lim(2)
%         node_curve(k,4)=-0.5;
%     end
% 
% 
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%making some plots%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%scaling for z
node_intensity(:,3)=node_intensity(:,3).*scale_fac;

%scaling curvature for z
node_curve(:,3)=node_curve(:,3).*scale_fac;

%scaling for z
node_cluster(:,3)=node_cluster(:,3).*scale_fac;
node_cluster_size(:,3)=node_cluster_size(:,3).*scale_fac;
node_cluster_intensity(:,3)=node_cluster_intensity(:,3).*scale_fac;

%getting the "cluster limits" for plotting
min_cl_plot=min(node_cluster(:,4));
max_cl_plot=max(node_cluster(:,4));

min_cl_size=min(node_cluster_size(:,4));
max_cl_size=max(node_cluster_size(:,4));

min_cl_int=min(node_cluster_intensity(:,4));
max_cl_int=max(node_cluster_intensity(:,4));

map_easy=colormap(jet);
map_easy(1,:)=0;

%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

figure, hold on;
subplot(3,2,1); 
plotmesh(node_curve,face_curve); colormap(ens_curve_map); shading interp; title(strcat('Curvature (All)-',a_label)); caxis([-0.5,0.5]);freezeColors
subplot(3,2,2);
plotmesh(node_cluster,face_cluster);  title('Cluster #'); caxis([min_cl_plot,max_cl_plot]);shading interp;
colormap(map_easy); colorbar; freezeColors

subplot(3,2,3);
plotmesh(node_curve,face_curve); colormap(ens_curve_map); shading interp; title(strcat('Curvature (All)-',a_label)); caxis([-0.5,0.5]); freezeColors
subplot(3,2,4);
plotmesh(node_cluster_size,face_cluster);  title('Cluster Size'); caxis([min_cl_size,max_cl_size]); shading interp;
colormap(map_easy); colorbar; freezeColors

subplot(3,2,5);
plotmesh(node_curve,face_curve); colormap(ens_curve_map);  shading interp; title(strcat('Curvature (All)-',a_label)); caxis([-0.5,0.5]);freezeColors
subplot(3,2,6); 
plotmesh(node_cluster_intensity,face_cluster); title('ClusterIntegrated Intensity'); caxis([min_cl_int,max_cl_int]);shading interp;
colormap(map_easy); colorbar; freezeColors


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%Some Excel Output%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get the high and the low cluster
idx_real_cl=find(node_cluster(:,4)>0);
low_c=min(node_cluster(idx_real_cl,4));
high_c=max(node_cluster(idx_real_cl,4));

%counter to load final matrix
count_jp=1;

for r=low_c:high_c

    %finding stuff
    idx_curr=find(node_cluster(:,4)==r);

    if numel(idx_curr)>0

        %get the size
        curr_size_arr=node_cluster_size(idx_curr,4);
        
        %get the integrated intensity
        curr_int_arr=node_cluster_intensity(idx_curr,4);
        
        %get the curvature
        curr_curv=node_curve(idx_curr,4);
        
        %storing
        stats_to_return(count_jp,1)=r; %cluster number
        stats_to_return(count_jp,2)=curr_size_arr(1); %cluster size
        stats_to_return(count_jp,3)=curr_int_arr(1);  %cluster intensity
        stats_to_return(count_jp,4)=mean(curr_curv); %mean curvature
        stats_to_return(count_jp,5)=std(curr_curv); %std dev of curvature

        %iterate counter
        count_jp=count_jp+1;

        %clear statements
        clear curr_size_arr; clear curr_int_arr;
        clear curr_curv;


    end

    %clear statements
    clear idx_curr;

end

if count_jp==1
    stats_to_return(1,1)=0;
    stats_to_return(1,2)=0;
    stats_to_return(1,3)=0;
    stats_to_return(1,4)=0;
    stats_to_return(1,5)=0;
end
