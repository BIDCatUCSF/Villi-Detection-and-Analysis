function[]=save_coords_curvature_to_excel_two_channel(arr_now1,arr_now2,file_to_save_xcel)

%This is a simple function written to save the sizes of clusters to excel
%sheets for easy analysis later

%input 
% arr_now(:,1) = x
% arr_now(:,2) = y
% arr_now(:,3) = z
% arr_now(:,4) = curvature
% arr_now(:,5) = intensity
% file_excel_save = filename to save data

%counter
count=1;
another_counter=1;
        
%x coordinates
x_now_en_1=arr_now1(:,1);
x_now_en_2=arr_now2(:,1);

%y coordinates
y_now_en_1=arr_now1(:,2);
y_now_en_2=arr_now2(:,2);

%z coordinates
z_now_en_1=arr_now1(:,3);
z_now_en_2=arr_now2(:,3);

%curvature
the_curve_now_1=arr_now1(:,4);
the_curve_now_2=arr_now2(:,4);

%intensity
the_intens_now_1=arr_now1(:,5);
the_intens_now_2=arr_now2(:,5);

if another_counter==1
    % adding headers
    str1={'Ch1: x'};
    str2={'Ch1: y'};
    str3={'Ch1: z'};
    str4={'Ch1: Curvature'};
    str5={'Ch1: Intensity'};
    str6={'Ch2: x'};
    str7={'Ch2: y'};
    str8={'Ch2: z'};
    str9={'Ch2: Curvature'};
    str10={'Ch2: Intensity'};
    xlswrite(file_to_save_xcel,str1,count,'A1');
    xlswrite(file_to_save_xcel,str2,count,'B1');
    xlswrite(file_to_save_xcel,str3,count,'C1');
    xlswrite(file_to_save_xcel,str4,count,'D1');
    xlswrite(file_to_save_xcel,str5,count,'E1');
    xlswrite(file_to_save_xcel,str6,count,'F1');
    xlswrite(file_to_save_xcel,str7,count,'G1');
    xlswrite(file_to_save_xcel,str8,count,'H1');
    xlswrite(file_to_save_xcel,str9,count,'I1');
    xlswrite(file_to_save_xcel,str10,count,'J1');
end


%adding data
cloc1_tmp=num2str(1+numel(x_now_en_1));
cloc1=strcat('A2:A',cloc1_tmp);
cloc2=strcat('B2:B',cloc1_tmp);
cloc3=strcat('C2:C',cloc1_tmp);
cloc4=strcat('D2:D',cloc1_tmp);
cloc5=strcat('E2:E',cloc1_tmp);

cloc2_tmp=num2str(1+numel(x_now_en_2));
cloc6=strcat('F2:F',cloc2_tmp);
cloc7=strcat('G2:G',cloc2_tmp);
cloc8=strcat('H2:H',cloc2_tmp);
cloc9=strcat('I2:I',cloc2_tmp);
cloc10=strcat('J2:J',cloc2_tmp);

%writing to the excel file
xlswrite(file_to_save_xcel,x_now_en_1,count,cloc1);
xlswrite(file_to_save_xcel,y_now_en_1,count,cloc2);
xlswrite(file_to_save_xcel,z_now_en_1,count,cloc3);
xlswrite(file_to_save_xcel,the_curve_now_1,count,cloc4);
xlswrite(file_to_save_xcel,the_intens_now_1,count,cloc5);

xlswrite(file_to_save_xcel,x_now_en_2,count,cloc6);
xlswrite(file_to_save_xcel,y_now_en_2,count,cloc7);
xlswrite(file_to_save_xcel,z_now_en_2,count,cloc8);
xlswrite(file_to_save_xcel,the_curve_now_2,count,cloc9);
xlswrite(file_to_save_xcel,the_intens_now_2,count,cloc10);

%iterate counter
another_counter=another_counter+1;


















