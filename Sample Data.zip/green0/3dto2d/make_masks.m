clear all; close all;

%This is a code written to make masks in order to study the 2d projection
%of En' data


%paths for saving
orig_save='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\3dto2d\original images\orig';
orig_mask_save='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\3dto2d\original mask\orig_mask';
eroded_save='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\3dto2d\eroded mask\emask';
cluster_save='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\3dto2d\cluster ims\cims';

%paths for image
path_orig='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\OTI_mTmG_fixed_then_labelwith_CD45A647_H57A488_onPLL_40_ch2_stack0000_488nm_0000000msec_0001984583msecAbs_decon';
path_erode='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\ErodedBoundaryImages\MaskBoundErode';
path_cl='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\WholeImageStackClustering\Intensity Stack\Im';

%path for boundarys
path_bound='C:\Users\jeichorst\Desktop\en project\20171109_Tcell_fix_label\OTI_mTmG_CD45_A647_H57_A488_onPLL\ROI40\CroppedFiles\green0\The_Boundaries\Bound';

%starting and ending indices
ns=29;
ne=80;

%counter
count=1;

for i=ns:ne
    
      
    i
    
   %read in the images - eroded boundary images
   er_im=imread(strcat(path_erode,num2str(i),'.tif'));
   
   %reading in the images
   cl_im=imread(strcat(path_cl,num2str(i),'.tif'));
   
   %read in the image - original image
   if i<10
       im_orig=imread(strcat(path_orig,'000',num2str(i),'.tif'));
   elseif i>9 && i<100
       im_orig=imread(strcat(path_orig,'00',num2str(i),'.tif'));
   else
       im_orig=imread(strcat(path_orig,'0',num2str(i),'.tif'));
   end
   
   %getting the dimension
   if count==1
      dim1=size(er_im,1); 
      dim2=size(er_im,2); 
   end
   
   %iterate counter
   count=count+1;
   
   %boundary
   bound_now_tmp=load(strcat(path_bound,num2str(i),'.mat'));
   bound_now=bound_now_tmp.boundary_out;
   
   %mask for original images
   orig_mask=poly2mask(bound_now(:,1),bound_now(:,2),dim1,dim2);
   
   %initializing mask
   er_mask=zeros(dim1,dim2);
   
   %finding non-zero entries
   idx_er=find(er_im>0);
   

   %making eroded boundary mask
   if numel(idx_er)>0
       er_mask(idx_er)=1;
   end
   
   %cluster image to save
   cl_im=double(cl_im);
   cl_save=cl_im+er_mask;
   
   %saving
   imwrite(uint16(im_orig),strcat(orig_save,num2str(i),'.tif'));
   imwrite(uint16(orig_mask),strcat(orig_mask_save,num2str(i),'.tif'));
   imwrite(uint16(er_mask),strcat(eroded_save,num2str(i),'.tif'));
   imwrite(uint16(cl_save),strcat(cluster_save,num2str(i),'.tif'));
   
   %clear statements
   clear cl_im; clear er_im; clear orig_mask; clear er_mask;
   clear idx_er; clear bound_now; clear bound_now_tmp; clear im_orig;
   clear cl_save; clear cl_im;
   
end



































